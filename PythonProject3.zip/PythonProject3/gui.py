import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import sys
import os
import threading
from datetime import datetime
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from algorithms.core_data import CairoTransportData
from algorithms.mst import MinimumSpanningTree
from algorithms.dijkstra import DijkstraRouter, find_all_paths
from algorithms.astar import AStarRouter
from algorithms.Dynamic import PublicTransitScheduler
from algorithms.greedy import TrafficSignalOptimizer
from algorithms.ml_predictor import TrafficPredictor, RouteOptimizerML

# Import visualization
try:
    import matplotlib.pyplot as plt
    import matplotlib.animation as animation
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    import networkx as nx
    from matplotlib.animation import FuncAnimation
    VISUALIZATION_AVAILABLE = True
except ImportError:
    VISUALIZATION_AVAILABLE = False
    print("Warning: matplotlib or networkx not installed. Install with: pip install matplotlib networkx")

plt.style.use('dark_background')


class AnimatedGraph:
    def __init__(self, parent_frame, network):
        self.parent = parent_frame
        self.network = network
        self.fig = Figure(figsize=(12, 9), facecolor='#1a1a2e', dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor('#0d0d1a')
        self.canvas = FigureCanvasTkAgg(self.fig, master=parent_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        # ===== جميع المناطق والمرافق (25 مكان) =====
        self.pos = {
            # المناطق (15)
            "New Administrative Capital": (95, 55),
            "New Cairo": (85, 50),
            "Al Rehab": (80, 48),
            "Heliopolis": (70, 55),
            "Nasr City": (65, 52),
            "Shubra": (50, 60),
            "Downtown Cairo": (45, 50),
            "Zamalek": (40, 45),
            "Mohandessin": (38, 42),
            "Giza": (30, 40),
            "Dokki": (35, 38),
            "Maadi": (45, 30),
            "Helwan": (50, 20),
            "6th October City": (15, 35),
            "Sheikh Zayed": (20, 30),

            # المرافق (10)
            "Cairo International Airport": (75, 62),
            "Ramses Railway Station": (48, 55),
            "Cairo University": (32, 35),
            "Al-Azhar University": (48, 48),
            "Egyptian Museum": (44, 48),
            "Cairo International Stadium": (62, 48),
            "Smart Village": (18, 28),
            "Cairo Festival City": (82, 42),
            "Qasr El Aini Hospital": (43, 46),
            "Maadi Military Hospital": (47, 28),
        }
    def draw_network(self, highlight_path=None, highlight_edges=None):
        """رسم شبكة الطرق"""
        self.ax.clear()
        self.ax.set_facecolor('#0d0d1a')

        G = nx.Graph()

        # إضافة العقد الموجودة في الـ positions فقط
        valid_nodes = [n for n in self.network.nodes if n in self.pos]
        for node in valid_nodes:
            color = '#ff4444' if node in self.network.critical_facilities else '#44aaff'
            G.add_node(node, color=color)

        # إضافة الحواف
        for u in self.network.graph:
            if u not in self.pos:
                continue
            for v, w in self.network.graph[u]:
                if v in self.pos and u < v:
                    G.add_edge(u, v, weight=w)

        # رسم كل الحواف باللون الرمادي
        nx.draw_networkx_edges(G, self.pos, edge_color='#555555', width=1.5, alpha=0.5, ax=self.ax)

        # رسم الحواف المميزة (MST أو مسار محدد)
        if highlight_edges:
            valid_highlight = [(u, v) for u, v in highlight_edges if u in self.pos and v in self.pos]
            if valid_highlight:
                nx.draw_networkx_edges(G, self.pos, edgelist=valid_highlight,
                                       edge_color='#00ff00', width=3.5, alpha=0.9, ax=self.ax)

        # رسم العقد
        node_colors = [G.nodes[n].get('color', '#44aaff') for n in G.nodes()]
        nx.draw_networkx_nodes(G, self.pos, node_color=node_colors, node_size=550, alpha=0.9, ax=self.ax)

        # رسم أسماء العقد
        nx.draw_networkx_labels(G, self.pos, font_size=7, font_weight='bold', font_color='white', ax=self.ax)

        # رسم المسار المميز
        if highlight_path and len(highlight_path) > 1:
            valid_path = [n for n in highlight_path if n in self.pos]
            if len(valid_path) > 1:
                path_edges = [(valid_path[i], valid_path[i + 1]) for i in range(len(valid_path) - 1)]
                nx.draw_networkx_edges(G, self.pos, edgelist=path_edges,
                                       edge_color='#ffaa00', width=4, alpha=1.0, ax=self.ax)
                nx.draw_networkx_nodes(G, self.pos, nodelist=valid_path, node_color='#ffaa00', node_size=650, alpha=1.0,
                                       ax=self.ax)

        self.ax.set_title("Cairo Transportation Network (25 Locations)", fontsize=14, fontweight='bold',
                          color='#00d4ff')
        self.ax.axis('off')

        # ضبط حدود الرسم
        self.ax.set_xlim(0, 105)
        self.ax.set_ylim(15, 70)

        self.canvas.draw()


class UltimateDynamicGUI:
    def __init__(self, root):
        self.root = root
        root.title("🏙️ Smart Cairo Transport System - Dynamic Edition")
        root.geometry("1650x1000")
        root.configure(bg="#0d0d1a")

        # Load network with new data
        self.network = CairoTransportData()
        self.network.build_cairo_network()
        self.nodes = sorted(list(self.network.nodes))

        self.traffic_predictor = TrafficPredictor()
        self.route_optimizer = RouteOptimizerML()

        self.transport_modes = {
            "🚗 Private Car": {"speed": 1.0, "cost_per_km": 5},
            "🚌 Public Bus": {"speed": 1.4, "cost_per_km": 2},
            "🚇 Metro": {"speed": 0.8, "cost_per_km": 3},
            "🚕 Taxi": {"speed": 1.1, "cost_per_km": 8},
            "🚲 Bike": {"speed": 2.5, "cost_per_km": 0}
        }

        self.traffic_options = {
            "normal": {"name": "Normal (1.0x)", "factor": 1.0},
            "morning": {"name": "Morning Rush (1.5x)", "factor": 1.5},
            "evening": {"name": "Evening Rush (1.4x)", "factor": 1.4},
            "night": {"name": "Night (0.8x)", "factor": 0.8}
        }

        self.setup_ui()

        if VISUALIZATION_AVAILABLE:
            self.animated_graph = AnimatedGraph(self.graph_frame, self.network)
            self.animated_graph.draw_network()
            self.log("✅ Graph visualization ready (25 locations)")
        else:
            self.log("⚠️ Visualization not available. Install: pip install matplotlib networkx")

    def setup_ui(self):
        # Title
        title = tk.Label(self.root, text="🏙️ SMART CAIRO TRANSPORTATION SYSTEM 🏙️",
                         font=("Arial", 20, "bold"), bg="#0d0d1a", fg="#00d4ff")
        title.pack(pady=10)

        # Main frame
        main_frame = tk.Frame(self.root, bg="#0d0d1a")
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # ========== LEFT PANEL (مع Scrollbar) ==========
        left_panel_container = tk.Frame(main_frame, bg="#1a1a2e", width=550)
        left_panel_container.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_panel_container.pack_propagate(False)

        # إضافة Canvas و Scrollbar
        canvas = tk.Canvas(left_panel_container, bg="#1a1a2e", highlightthickness=0)
        scrollbar = tk.Scrollbar(left_panel_container, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#1a1a2e")

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw", width=530)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # ===== كل المحتوى في scrollable_frame =====

        # Route Selection
        route_frame = tk.LabelFrame(scrollable_frame, text="📍 ROUTE SELECTION",
                                    bg="#1a1a2e", fg="#ffd966", font=("Arial", 12, "bold"))
        route_frame.pack(fill=tk.X, padx=10, pady=10)

        tk.Label(route_frame, text="From (Origin):", bg="#1a1a2e", fg="white", font=("Arial", 10)).pack(anchor="w",
                                                                                                        padx=10,
                                                                                                        pady=(10, 0))
        self.from_cb = ttk.Combobox(route_frame, values=self.nodes, width=38, font=("Arial", 10))
        self.from_cb.pack(padx=10, pady=5, fill=tk.X)
        self.from_cb.set("Nasr City" if "Nasr City" in self.nodes else self.nodes[0] if self.nodes else "")

        tk.Label(route_frame, text="To (Destination):", bg="#1a1a2e", fg="white", font=("Arial", 10)).pack(anchor="w",
                                                                                                           padx=10,
                                                                                                           pady=(10, 0))
        self.to_cb = ttk.Combobox(route_frame, values=self.nodes, width=38, font=("Arial", 10))
        self.to_cb.pack(padx=10, pady=5, fill=tk.X)
        self.to_cb.set("Giza" if "Giza" in self.nodes else self.nodes[-1] if self.nodes else "")

        # Transport Mode
        tk.Label(route_frame, text="Transport Mode:", bg="#1a1a2e", fg="#ffd966", font=("Arial", 11, "bold")).pack(
            anchor="w", padx=10, pady=(15, 5))

        self.transport_var = tk.StringVar(value="🚗 Private Car")
        modes_frame = tk.Frame(route_frame, bg="#1a1a2e")
        modes_frame.pack(padx=10, pady=5, fill=tk.X)

        for i, mode in enumerate(self.transport_modes):
            rb = tk.Radiobutton(modes_frame, text=mode, variable=self.transport_var, value=mode,
                                bg="#1a1a2e", fg="white", selectcolor="#1a1a2e", font=("Arial", 9))
            rb.grid(row=i // 2, column=i % 2, sticky="w", padx=5, pady=2)

        # Traffic Condition
        tk.Label(route_frame, text="Traffic Condition:", bg="#1a1a2e", fg="#ffd966", font=("Arial", 11, "bold")).pack(
            anchor="w", padx=10, pady=(15, 5))

        self.traffic_var = tk.StringVar(value="normal")
        traffic_frame = tk.Frame(route_frame, bg="#1a1a2e")
        traffic_frame.pack(padx=10, pady=5, fill=tk.X)

        tk.Radiobutton(traffic_frame, text="🌞 Normal (1.0x)", variable=self.traffic_var, value="normal",
                       bg="#1a1a2e", fg="#00ffcc").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(traffic_frame, text="🌅 Morning Rush (1.5x)", variable=self.traffic_var, value="morning",
                       bg="#1a1a2e", fg="#ffaa00").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(traffic_frame, text="🌆 Evening Rush (1.4x)", variable=self.traffic_var, value="evening",
                       bg="#1a1a2e", fg="#ff5533").pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(traffic_frame, text="🌙 Night (0.8x)", variable=self.traffic_var, value="night",
                       bg="#1a1a2e", fg="#8888ff").pack(side=tk.LEFT, padx=5)

        # ========== ACTION BUTTONS ==========
        btn_frame = tk.LabelFrame(scrollable_frame, text="🚀 ACTIONS", bg="#1a1a2e", fg="#ffd966",
                                  font=("Arial", 11, "bold"))
        btn_frame.pack(fill=tk.X, padx=10, pady=10)

        buttons = [
            ("🛣️ SHOW ALL PATHS", self.show_all_paths, "#2d6a4f"),
            ("⭐ BEST ROUTE (with ML & Animation)", self.show_best_path_with_ml, "#9e2a2a"),
            ("⭐ BEST ROUTE (without ML)", self.show_best_path_without_ml, "#c0392b"),
            ("🚑 EMERGENCY (AMBULANCE)", self.emergency_route, "#e74c3c"),
            ("🗺️ SHOW MST GRAPH (Kruskal)", self.show_mst_graph, "#27ae60"),
            ("🗺️ SHOW MST GRAPH (Prim)", self.show_mst_graph_prim, "#2ecc71"),
            ("📊 COMPARE MST (Kruskal vs Prim)", self.compare_mst_algorithms, "#e67e22"),
            ("📊 COMPARE A* vs DIJKSTRA", self.compare_astar_dijkstra, "#e67e22"),
            ("🤖 AI TRAFFIC PREDICTION", self.show_ml_prediction, "#8e44ad"),
            ("🌐 RESET NETWORK VIEW", self.reset_graph, "#3498db"),
            ("🗑️ CLEAR OUTPUT", self.clear_output, "#5a3a3a")
        ]

        for text, cmd, color in buttons:
            btn = tk.Button(btn_frame, text=text, command=cmd,
                            bg=color, fg="white", font=("Arial", 9, "bold"), pady=5)
            btn.pack(fill=tk.X, pady=2)

        # AI Insights
        ai_frame = tk.LabelFrame(scrollable_frame, text="🤖 AI INSIGHTS", bg="#1a1a2e", fg="#00d4ff", font=("Arial", 10))
        ai_frame.pack(fill=tk.X, padx=10, pady=10)

        self.ai_label = tk.Label(ai_frame, text="🤖 AI Assistant Active\nSelect a route for recommendations",
                                 bg="#1a1a2e", fg="#888888", font=("Arial", 9), wraplength=480, justify=tk.LEFT)
        self.ai_label.pack(padx=10, pady=10)

        # ========== RIGHT PANEL ==========
        right_frame = tk.Frame(main_frame, bg="#0d0d1a")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # Graph display area
        self.graph_frame = tk.Frame(right_frame, bg="#0d0d1a", height=450)
        self.graph_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        self.graph_frame.pack_propagate(False)

        # Output area
        output_frame = tk.LabelFrame(right_frame, text="📋 OUTPUT CONSOLE",
                                     bg="#0d0d1a", fg="#00d4ff", font=("Arial", 11, "bold"))
        output_frame.pack(fill=tk.BOTH, expand=True)

        self.output_text = scrolledtext.ScrolledText(output_frame, wrap=tk.WORD,
                                                     font=("Consolas", 10),
                                                     bg="#0d0d1a", fg="#00ffcc",
                                                     height=15)
        self.output_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Status
        self.status = tk.Label(self.root, text="✅ Ready | AI Enhanced System Active",
                               bd=1, relief=tk.SUNKEN, anchor=tk.W,
                               bg="#1a1a2e", fg="#aaaaaa", font=("Arial", 10))
        self.status.pack(side=tk.BOTTOM, fill=tk.X)

        self.log("=" * 80)
        self.log("🏙️  SMART CAIRO TRANSPORTATION SYSTEM - DYNAMIC EDITION")
        self.log("=" * 80)
        self.log(f"✅ Loaded {len(self.network.nodes)} locations in Greater Cairo")
        self.log(f"📍 Available locations: {', '.join(self.nodes[:20])}...")
        self.log(f"🏥 Critical facilities: {', '.join(self.network.critical_facilities)}")
        self.log("=" * 80)

    def log(self, msg):
        self.output_text.insert(tk.END, msg + "\n")
        self.output_text.see(tk.END)
        self.root.update()

    def clear_output(self):
        self.output_text.delete(1.0, tk.END)
        self.log("✨ Output cleared.")

    def reset_graph(self):
        if VISUALIZATION_AVAILABLE:
            self.animated_graph.draw_network()
            self.log("✅ Network view reset")
        else:
            self.log("⚠️ Visualization not available")

    def get_traffic_info(self):
        t = self.traffic_var.get()
        return {"factor": self.traffic_options.get(t, {"factor": 1.0})["factor"],
                "name": self.traffic_options.get(t, {"name": "Normal"})["name"]}

    def get_transport_info(self):
        mode = self.transport_var.get()
        return self.transport_modes.get(mode, {"speed": 1.0, "cost_per_km": 5})

    def show_all_paths(self):
        start = self.from_cb.get()
        end = self.to_cb.get()

        if start not in self.network.nodes or end not in self.network.nodes:
            self.log(f"❌ Invalid selection: {start} -> {end}")
            return

        traffic = self.get_traffic_info()
        transport = self.get_transport_info()
        factor = traffic["factor"]
        speed = transport["speed"]
        cost_per_km = transport["cost_per_km"]

        self.log("\n" + "█" * 80)
        self.log(f"🛣️  ALL POSSIBLE PATHS: {start} → {end}")
        self.log(f"   🚦 Transport: {self.transport_var.get()}")
        self.log(f"   ⏰ Traffic: {traffic['name']}")
        self.log("█" * 80)

        paths = find_all_paths(self.network, start, end, max_paths=8)

        if not paths:
            self.log("❌ No paths found!")
            return

        for i, (path, base_time) in enumerate(paths, 1):
            adjusted = base_time * factor * speed
            distance_km = base_time * 0.5
            cost = distance_km * cost_per_km

            marker = "⭐ BEST ⭐" if i == 1 else "    "
            self.log(f"\n{marker} ROUTE #{i}:")
            self.log(f"   📍 Path: {' → '.join(path)}")
            self.log(f"   ⏱️  Time: {adjusted:.1f} minutes")
            self.log(f"   💰 Cost: {cost:.0f} EGP")

    def show_best_path_without_ml(self):
        start = self.from_cb.get()
        end = self.to_cb.get()

        if start not in self.network.nodes or end not in self.network.nodes:
            self.log(f"❌ Invalid: {start} -> {end}")
            return

        traffic = self.get_traffic_info()
        transport = self.get_transport_info()
        factor = traffic["factor"]
        speed = transport["speed"]
        cost_per_km = transport["cost_per_km"]

        self.log("\n" + "⭐" * 40)
        self.log(f"⭐ BEST ROUTE (Without ML) : {start} → {end}")
        self.log("⭐" * 40)

        # Get shortest path
        path, base_time, _ = DijkstraRouter.find_shortest_path(self.network, start, end)

        adjusted_time = base_time * factor * speed
        distance_km = base_time * 0.5
        cost = distance_km * cost_per_km

        self.log(f"\n🛣️  OPTIMAL ROUTE:")
        self.log(f"   📍 Path: {' → '.join(path)}")
        self.log(f"   ⏱️  Time: {adjusted_time:.1f} minutes")
        self.log(f"   💰 Cost: {cost:.0f} EGP")

        if VISUALIZATION_AVAILABLE:
            self.animated_graph.draw_network(highlight_path=path)

    def show_best_path_with_ml(self):
        self.show_best_path_without_ml()

    def emergency_route(self):
        start = self.from_cb.get()
        end = self.to_cb.get()

        self.log("\n" + "🚑" * 40)
        self.log(f"🚨 EMERGENCY ROUTE: {start} → {end}")
        self.log("🚑" * 40)

        path, time_val, visited = AStarRouter.emergency_routing(self.network, start, end)

        self.log(f"\n📍 EMERGENCY ROUTE:")
        self.log(f"   Path: {' → '.join(path)}")
        self.log(f"   ⏱️  Response time: {time_val:.1f} minutes")
        self.log(f"   🔍 Nodes explored: {visited}")

        if VISUALIZATION_AVAILABLE:
            self.animated_graph.draw_network(highlight_path=path)

    # ==================== MST KRUSKAL ====================
    def show_mst_graph(self):
        """عرض MST باستخدام خوارزمية Kruskal مع رسم Graph"""
        self.log("\n" + "🌲" * 40)
        self.log("MINIMUM SPANNING TREE (Kruskal's Algorithm)")
        self.log("🌲" * 40)

        import time
        start_time = time.perf_counter_ns()
        result = MinimumSpanningTree.kruskal_with_constraints(self.network)
        kruskal_time = (time.perf_counter_ns() - start_time) / 1000

        self.log(f"\n📊 RESULTS:")
        self.log(f"   • Total cost: {result['total_cost']} minutes")
        self.log(f"   • Number of edges: {len(result['edges'])}")
        self.log(f"   • Critical facilities connected: {result['critical_facilities_connected']}/{len(self.network.critical_facilities)}")
        self.log(f"   • Computation time: {kruskal_time:.2f} microseconds")
        self.log(f"\n🛣️  MST EDGES (Roads to build):")

        for u, v, w in result['edges'][:15]:
            self.log(f"   • {u} ↔ {v}: {w} minutes")

        if len(result['edges']) > 15:
            self.log(f"   ... and {len(result['edges']) - 15} more edges")

        # رسم الـ MST على الخريطة
        if VISUALIZATION_AVAILABLE and result['edges']:
            mst_edges = [(u, v) for u, v, w in result['edges']]
            self.animated_graph.draw_network(highlight_edges=mst_edges)
            self.log("\n✅ MST (Kruskal) displayed on graph (green edges)")
        else:
            self.log("⚠️ Cannot display MST - visualization not available")


    # ==================== MST PRIM ====================
    def show_mst_graph_prim(self):
        """عرض MST باستخدام خوارزمية Prim مع رسم Graph"""
        self.log("\n" + "🌲" * 40)
        self.log("MINIMUM SPANNING TREE (Prim's Algorithm - Population Priority)")
        self.log("🌲" * 40)

        import time
        start_time = time.perf_counter_ns()
        result = MinimumSpanningTree.prim_with_population_priority(self.network)
        prim_time = (time.perf_counter_ns() - start_time) / 1000

        self.log(f"\n📊 RESULTS:")
        self.log(f"   • Total cost: {result['total_cost']} minutes")
        self.log(f"   • Number of edges: {len(result['edges'])}")
        self.log(f"   • Algorithm: {result['algorithm']}")
        self.log(f"   • Computation time: {prim_time:.2f} microseconds")
        self.log(f"\n🛣️  MST EDGES (Prioritizing high-population areas):")

        for u, v, w in result['edges'][:15]:
            self.log(f"   • {u} ↔ {v}: {w} minutes")

        if len(result['edges']) > 15:
            self.log(f"   ... and {len(result['edges']) - 15} more edges")

        # رسم الـ MST على الخريطة
        if VISUALIZATION_AVAILABLE and result['edges']:
            mst_edges = [(u, v) for u, v, w in result['edges']]
            self.animated_graph.draw_network(highlight_edges=mst_edges)
            self.log("\n✅ MST (Prim) displayed on graph (green edges)")
        else:
            self.log("⚠️ Cannot display MST - visualization not available")

    # ==================== COMPARE MST ====================
    def compare_mst_algorithms(self):
        """مقارنة بين خوارزميات Kruskal و Prim"""
        self.log("\n" + "📊" * 40)
        self.log("COMPARING MST ALGORITHMS: KRUSKAL vs PRIM")
        self.log("📊" * 40)

        import time

        # Kruskal
        start_time = time.perf_counter_ns()
        kruskal_result = MinimumSpanningTree.kruskal_with_constraints(self.network)
        kruskal_time = (time.perf_counter_ns() - start_time) / 1000

        # Prim
        start_time = time.perf_counter_ns()
        prim_result = MinimumSpanningTree.prim_with_population_priority(self.network)
        prim_time = (time.perf_counter_ns() - start_time) / 1000

        # عرض النتائج
        self.log(f"\n{'='*60}")
        self.log(f"🌲 KRUSKAL'S ALGORITHM:")
        self.log(f"   • Total cost: {kruskal_result['total_cost']} minutes")
        self.log(f"   • Number of edges: {len(kruskal_result['edges'])}")
        self.log(f"   • Critical facilities connected: {kruskal_result.get('critical_facilities_connected', 'N/A')}")
        self.log(f"   • Computation time: {kruskal_time:.2f} microseconds")
        self.log(f"   • Strategy: Sort edges by weight, add smallest first")

        self.log(f"\n🌲 PRIM'S ALGORITHM (Population Priority):")
        self.log(f"   • Total cost: {prim_result['total_cost']} minutes")
        self.log(f"   • Number of edges: {len(prim_result['edges'])}")
        self.log(f"   • Computation time: {prim_time:.2f} microseconds")
        self.log(f"   • Strategy: Start from highest population area, grow MST")

        # مقارنة
        self.log(f"\n{'='*60}")
        self.log(f"📊 COMPARISON RESULTS:")
        self.log(f"{'='*60}")

        cost_diff = abs(kruskal_result['total_cost'] - prim_result['total_cost'])
        if kruskal_result['total_cost'] < prim_result['total_cost']:
            self.log(f"   🟢 Kruskal is CHEAPER by {cost_diff:.1f} minutes")
        elif prim_result['total_cost'] < kruskal_result['total_cost']:
            self.log(f"   🟢 Prim is CHEAPER by {cost_diff:.1f} minutes")
        else:
            self.log(f"   🟡 Both algorithms have the SAME cost")

        if kruskal_time < prim_time:
            self.log(f"   🚀 Kruskal is FASTER by {(prim_time - kruskal_time):.2f} μs")
        elif prim_time < kruskal_time:
            self.log(f"   🚀 Prim is FASTER by {(kruskal_time - prim_time):.2f} μs")
        else:
            self.log(f"   🟡 Both algorithms have the SAME speed")

        self.log(f"\n💡 RECOMMENDATION:")
        if kruskal_result['total_cost'] <= prim_result['total_cost']:
            self.log(f"   • Use Kruskal for minimal construction cost")
            self.log(f"   • Best for: Connecting all areas with minimum total distance")
        else:
            self.log(f"   • Use Prim for population-prioritized connections")
            self.log(f"   • Best for: Ensuring high-density areas are well-connected")

    def compare_astar_dijkstra(self):
        start = self.from_cb.get()
        end = self.to_cb.get()

        self.log("\n" + "📊" * 40)
        self.log(f"COMPARING A* vs DIJKSTRA: {start} → {end}")
        self.log("📊" * 40)

        import time

        # Dijkstra
        start_time = time.perf_counter_ns()
        d_path, d_time, d_visited = DijkstraRouter.find_shortest_path(self.network, start, end)
        d_exec_time = (time.perf_counter_ns() - start_time) / 1000

        # A*
        start_time = time.perf_counter_ns()
        a_path, a_time, a_visited = AStarRouter.emergency_routing(self.network, start, end)
        a_exec_time = (time.perf_counter_ns() - start_time) / 1000

        self.log(f"\n🚗 DIJKSTRA:")
        self.log(f"   Time: {d_time:.1f} minutes")
        self.log(f"   Nodes explored: {d_visited}")
        self.log(f"   Computation: {d_exec_time:.2f} μs")

        self.log(f"\n🚑 A*:")
        self.log(f"   Time: {a_time:.1f} minutes")
        self.log(f"   Nodes explored: {a_visited}")
        self.log(f"   Computation: {a_exec_time:.2f} μs")

        if a_visited < d_visited:
            self.log(f"\n✅ A* is more efficient (explored {d_visited - a_visited} fewer nodes)")
        elif d_visited < a_visited:
            self.log(f"\n✅ Dijkstra is more efficient (explored {a_visited - d_visited} fewer nodes)")
        else:
            self.log(f"\n⚖️ Both algorithms explored the same number of nodes")

    def show_ml_prediction(self):
        current_hour = datetime.now().hour
        self.log("\n" + "🤖" * 40)
        self.log("AI TRAFFIC PREDICTION")
        self.log("🤖" * 40)
        self.log(f"\n🕐 Current time: {current_hour}:00")

        self.log(f"\n📊 TRAFFIC MULTIPLIERS BY TIME:")
        self.log(f"   • Morning (7-9 AM): 1.5x (HEAVY)")
        self.log(f"   • Afternoon (12-3 PM): 1.0x (NORMAL)")
        self.log(f"   • Evening (5-8 PM): 1.4x (HEAVY)")
        self.log(f"   • Night (10 PM-5 AM): 0.8x (LIGHT)")

        self.log(f"\n💡 RECOMMENDATION:")
        if 7 <= current_hour <= 9:
            self.log(f"   • It's MORNING RUSH HOUR - Expect delays")
            self.log(f"   • Recommendation: Use Metro or leave after 10 AM")
        elif 17 <= current_hour <= 20:
            self.log(f"   • It's EVENING RUSH HOUR - Expect congestion")
            self.log(f"   • Recommendation: Use Metro or wait until 8 PM")
        elif current_hour <= 5 or current_hour >= 22:
            self.log(f"   • It's NIGHT TIME - Light traffic")
            self.log(f"   • Recommendation: Perfect time for travel")
        else:
            self.log(f"   • It's NORMAL HOURS - Good time to travel")


if __name__ == "__main__":
    root = tk.Tk()
    app = UltimateDynamicGUI(root)
    root.mainloop()