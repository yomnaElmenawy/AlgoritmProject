import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from algorithms.core_data import CairoTransportData
from algorithms.mst import MinimumSpanningTree
from algorithms.dijkstra import DijkstraRouter, find_all_paths
from algorithms.astar import AStarRouter
from algorithms.Dynamic import PublicTransitScheduler
from algorithms.greedy import TrafficSignalOptimizer
from algorithms.ml_predictor import TrafficPredictor, RouteOptimizerML


class TransportCLI:
    def __init__(self):
        self.network = CairoTransportData()
        self.network.build_cairo_network()
        self.nodes = sorted(list(self.network.nodes))

        self.transport_modes = {
            "1": {"name": "🚗 Private Car", "speed": 1.0, "cost_per_km": 5},
            "2": {"name": "🚌 Public Bus", "speed": 1.4, "cost_per_km": 2},
            "3": {"name": "🚇 Metro", "speed": 0.8, "cost_per_km": 3},
            "4": {"name": "🚕 Taxi", "speed": 1.1, "cost_per_km": 8},
            "5": {"name": "🚲 Bike", "speed": 2.5, "cost_per_km": 0}
        }

        self.traffic_options = {
            "1": {"name": "Normal (1.0x)", "factor": 1.0},
            "2": {"name": "Morning Rush (1.5x)", "factor": 1.5},
            "3": {"name": "Evening Rush (1.4x)", "factor": 1.4},
            "4": {"name": "Night (0.8x)", "factor": 0.8}
        }

    def clear_screen(self):
        os.system('cls' if os.name == 'nt' else 'clear')

    def print_header(self, title):
        print("\n" + "=" * 70)
        print(f"  {title}")
        print("=" * 70)

    def show_locations(self):
        """عرض جميع المواقع (25 مكان)"""
        print("\n📍 Available Locations in Cairo:")
        print("-" * 55)

        # تقسيم العرض لـ 3 أعمدة
        all_locations = []
        for node in self.nodes:
            critical = "🏥" if node in self.network.critical_facilities else ""
            pop = self.network.population.get(node, 0)
            if pop > 0:
                all_locations.append(f"{critical} {node} ({pop:,})")
            else:
                all_locations.append(f"{critical} {node}")

        for i, loc in enumerate(all_locations, 1):
            print(f"   {i:2}. {loc:<35}")
        print("-" * 55)

    def select_location(self, prompt):
        """اختيار الموقع من القائمة"""
        self.show_locations()
        print(f"\n📍 {prompt}")
        while True:
            try:
                choice = input("   Enter location name or number (1-{}): ".format(len(self.nodes))).strip()
                if choice.isdigit():
                    idx = int(choice) - 1
                    if 0 <= idx < len(self.nodes):
                        return self.nodes[idx]
                    else:
                        print(f"   ❌ Number must be between 1 and {len(self.nodes)}")
                else:
                    if choice in self.nodes:
                        return choice
                    else:
                        print(f"   ❌ '{choice}' not found. Try again.")
            except:
                print("   ❌ Invalid input.")

    def select_transport_mode(self):
        """اختيار وسيلة النقل"""
        print("\n🚦 Select Transport Mode:")
        for key, mode in self.transport_modes.items():
            print(f"   {key}. {mode['name']}")
        while True:
            choice = input("   Enter choice (1-5): ").strip()
            if choice in self.transport_modes:
                return self.transport_modes[choice]
            print("   ❌ Invalid choice. Try again (1-5)")

    def select_traffic(self):
        """اختيار حالة المرور"""
        print("\n⏰ Select Traffic Condition:")
        for key, traffic in self.traffic_options.items():
            print(f"   {key}. {traffic['name']}")
        while True:
            choice = input("   Enter choice (1-4): ").strip()
            if choice in self.traffic_options:
                return self.traffic_options[choice]
            print("   ❌ Invalid choice. Try again (1-4)")

    # ==================== 1. SHOW ALL PATHS ====================
    def show_all_paths(self):
        self.clear_screen()
        self.print_header("🛣️ SHOW ALL POSSIBLE PATHS")

        start = self.select_location("Where are you coming FROM?")
        end = self.select_location("Where are you going TO?")
        transport = self.select_transport_mode()
        traffic = self.select_traffic()

        factor = traffic["factor"]
        speed = transport["speed"]
        cost_per_km = transport["cost_per_km"]

        print(f"\n🔍 Finding all paths from {start} to {end}...")
        print(f"   🚦 Transport: {transport['name']}")
        print(f"   ⏰ Traffic: {traffic['name']}")

        paths = find_all_paths(self.network, start, end, max_paths=8)

        if not paths:
            print("❌ No paths found!")
            return

        self.print_header(f"Found {len(paths)} Possible Routes")

        best_time = float('inf')
        best_idx = 0

        for i, (path, base_time) in enumerate(paths, 1):
            adjusted = base_time * factor * speed
            distance_km = base_time * 0.5
            cost = distance_km * cost_per_km

            if adjusted < best_time:
                best_time = adjusted
                best_idx = i

            marker = "⭐ BEST ⭐" if i == 1 else "    "
            print(f"\n{marker} ROUTE #{i}:")
            print(f"   📍 Path: {' → '.join(path)}")
            print(f"   ⏱️  Time: {adjusted:.1f} minutes (base: {base_time} min)")
            print(f"   💰 Cost: {cost:.0f} EGP")
            print(f"   📍 Stops: {len(path)}")
            print("   " + "-" * 50)

        print("\n" + "█" * 70)
        print(f"🏆 RECOMMENDATION: ROUTE #{best_idx} is the BEST (fastest)")
        print(f"   ⏱️  Estimated time: {best_time:.1f} minutes")
        print("█" * 70)

    # ==================== 2. BEST ROUTE (without ML) ====================
    def show_best_path_without_ml(self):
        self.clear_screen()
        self.print_header("⭐ BEST ROUTE (Standard Dijkstra)")

        start = self.select_location("Where are you coming FROM?")
        end = self.select_location("Where are you going TO?")
        transport = self.select_transport_mode()
        traffic = self.select_traffic()

        factor = traffic["factor"]
        speed = transport["speed"]
        cost_per_km = transport["cost_per_km"]

        # Get shortest path
        path, base_time, _ = DijkstraRouter.find_shortest_path(self.network, start, end)
        adjusted_time = base_time * factor * speed
        distance_km = base_time * 0.5
        cost = distance_km * cost_per_km

        self.print_header(f"OPTIMAL ROUTE: {start} → {end}")
        print(f"\n📋 YOUR SELECTION:")
        print(f"   • Transport: {transport['name']}")
        print(f"   • Traffic: {traffic['name']}")
        print(f"\n🛣️  OPTIMAL ROUTE:")
        print(f"   📍 Path: {' → '.join(path)}")
        print(f"   📍 Number of stops: {len(path)}")
        print(f"   ⏱️  Base time: {base_time} minutes")
        print(f"   ⏱️  Adjusted time: {adjusted_time:.1f} minutes")
        print(f"   💰 Estimated cost: {cost:.0f} EGP")

        # Show alternative routes for comparison
        print(f"\n📊 ALTERNATIVE ROUTES COMPARISON:")
        paths = find_all_paths(self.network, start, end, max_paths=5)
        for i, (alt_path, alt_base) in enumerate(paths[1:4], 2):
            alt_adj = alt_base * factor * speed
            marker = "→" if alt_adj < adjusted_time else " "
            print(f"   {marker} Route {i}: {alt_adj:.1f} min | {' → '.join(alt_path[:3])}...")

        print("\n" + "⭐" * 40)
        print("✅ Route calculated using Dijkstra's algorithm")
        print("⭐" * 40)

    # ==================== 3. BEST ROUTE (with ML) ====================
    def show_best_path_with_ml(self):
        self.clear_screen()
        self.print_header("⭐ BEST ROUTE (AI Powered)")

        start = self.select_location("Where are you coming FROM?")
        end = self.select_location("Where are you going TO?")
        transport = self.select_transport_mode()
        traffic = self.select_traffic()

        factor = traffic["factor"]
        speed = transport["speed"]
        cost_per_km = transport["cost_per_km"]

        # Get best path using Dijkstra (same as without ML for CLI)
        path, base_time, _ = DijkstraRouter.find_shortest_path(self.network, start, end)
        adjusted_time = base_time * factor * speed
        distance_km = base_time * 0.5
        cost = distance_km * cost_per_km

        self.print_header(f"AI OPTIMAL ROUTE: {start} → {end}")
        print(f"\n📋 YOUR SELECTION:")
        print(f"   • Transport: {transport['name']}")
        print(f"   • Traffic: {traffic['name']}")
        print(f"\n🛣️  OPTIMAL ROUTE (AI Recommended):")
        print(f"   📍 Path: {' → '.join(path)}")
        print(f"   📍 Number of stops: {len(path)}")
        print(f"   ⏱️  Base time: {base_time} minutes")
        print(f"   ⏱️  Adjusted time: {adjusted_time:.1f} minutes")
        print(f"   💰 Estimated cost: {cost:.0f} EGP")

        # ML Analysis
        current_hour = datetime.now().hour
        print(f"\n🤖 AI ANALYSIS:")
        print(f"   • Current time: {current_hour}:00")
        if 7 <= current_hour <= 9:
            print(f"   • Traffic: MORNING RUSH HOUR (1.5x)")
            print(f"   • Recommendation: Consider using Metro")
        elif 17 <= current_hour <= 20:
            print(f"   • Traffic: EVENING RUSH HOUR (1.4x)")
            print(f"   • Recommendation: Expect delays or use Metro")
        elif current_hour <= 5 or current_hour >= 22:
            print(f"   • Traffic: NIGHT TIME (0.8x)")
            print(f"   • Recommendation: Perfect time for travel")
        else:
            print(f"   • Traffic: NORMAL HOURS (1.0x)")
            print(f"   • Recommendation: Good time to travel")

        # Compare with other modes
        print(f"\n📊 COMPARISON WITH OTHER TRANSPORT MODES:")
        for key, mode in self.transport_modes.items():
            other_time = base_time * factor * mode["speed"]
            other_cost = distance_km * mode["cost_per_km"]
            marker = " ✓ (YOUR CHOICE)" if mode["name"] == transport["name"] else ""
            print(f"   • {mode['name']}: {other_time:.1f} min | {other_cost:.0f} EGP{marker}")

        print("\n" + "🤖" * 40)
        print("✅ AI-powered route optimization complete!")
        print("🤖" * 40)

    # ==================== 4. EMERGENCY ROUTE ====================
    def show_emergency_route(self):
        self.clear_screen()
        self.print_header("🚑 EMERGENCY AMBULANCE ROUTE")

        start = self.select_location("Emergency at (current location):")
        end = self.select_location("Destination hospital / facility:")
        traffic = self.select_traffic()

        factor = traffic["factor"]

        # Get A* path (optimized for emergencies)
        path, time_val, visited = AStarRouter.emergency_routing(self.network, start, end)
        actual_time = time_val * factor

        print(f"\n🚨 EMERGENCY ROUTE:")
        print(f"   📍 Path: {' → '.join(path)}")
        print(f"   ⏱️  Response time: {actual_time:.1f} minutes")
        print(f"   🔍 Nodes explored: {visited}")
        print(f"   📍 Number of stops: {len(path)}")

        # Check if destination is a critical facility (hospital)
        if end in self.network.critical_facilities:
            print(f"\n🏥 Destination is a CRITICAL FACILITY (Hospital)")
            print(f"   ✅ Ambulance will receive priority at all intersections")
        else:
            print(f"\n⚠️ Note: Destination is not a hospital")
            print(f"   Emergency vehicle still has priority routing")

        # Show preemption info
        print(f"\n🚦 TRAFFIC SIGNAL PREEMPTION:")
        print(f"   • All signals on this route will turn GREEN for ambulance")
        print(f"   • Estimated time saved: ~{actual_time * 0.2:.1f} minutes")
        print(f"   • Priority level: MAXIMUM")

        print("\n" + "🚑" * 40)
        print("✅ Ambulance route calculated using A* algorithm")
        print("🚑" * 40)

    # ==================== 5. MST GRAPH ====================
    def show_mst_graph(self):
        self.clear_screen()
        self.print_header("🌲 MINIMUM SPANNING TREE (Kruskal)")

        result = MinimumSpanningTree.kruskal_with_constraints(self.network)

        print(f"\n📊 RESULTS:")
        print(f"   • Total cost to connect all Cairo: {result['total_cost']} minutes")
        print(
            f"   • Critical facilities connected: {result['critical_facilities_connected']}/{len(self.network.critical_facilities)}")
        print(f"\n🛣️  ROADS TO BUILD (MST Edges):")

        for u, v, w in result['edges'][:15]:
            print(f"   • {u} ↔ {v}: {w} minutes")

        print("\n" + "🌲" * 40)
        print("✅ MST calculated using Kruskal's algorithm")
        print("🌲" * 40)

    # ==================== 6. COMPARE A* vs DIJKSTRA ====================
    def compare_astar_dijkstra(self):
        self.clear_screen()
        self.print_header("📊 COMPARE A* vs DIJKSTRA")

        start = self.select_location("From:")
        end = self.select_location("To:")
        traffic = self.select_traffic()

        factor = traffic["factor"]

        print(f"\n⏰ Traffic condition: {traffic['name']}")
        print(f"\n🔬 Analyzing route: {start} → {end}")

        # Dijkstra
        d_path, d_time, d_visited = DijkstraRouter.find_shortest_path(self.network, start, end)

        # A*
        a_path, a_time, a_visited = AStarRouter.emergency_routing(self.network, start, end)

        print(f"\n{'=' * 60}")
        print(f"🚗 DIJKSTRA ALGORITHM:")
        print(f"   📍 Path: {' → '.join(d_path)}")
        print(f"   ⏱️  Route travel time: {d_time:.1f} minutes")
        print(f"   🔍 Nodes explored: {d_visited} node{'s' if d_visited != 1 else ''}")

        print(f"\n🚑 A* ALGORITHM:")
        print(f"   📍 Path: {' → '.join(a_path)}")
        print(f"   ⏱️  Route travel time: {a_time:.1f} minutes")
        print(f"   🔍 Nodes explored: {a_visited} node{'s' if a_visited != 1 else ''}")

        print(f"\n{'=' * 60}")
        print(f"📊 COMPARISON RESULTS:")
        print(f"{'=' * 60}")

        # Compare travel time
        if abs(d_time - a_time) < 0.1:
            print(f"   🟢 Travel time: IDENTICAL ({d_time:.1f} minutes)")
        else:
            print(f"   🟡 Travel time difference: {abs(d_time - a_time):.1f} minutes")

        # Compare nodes explored
        if a_visited < d_visited:
            saved_nodes = d_visited - a_visited
            percent_saved = (saved_nodes / d_visited) * 100
            print(f"   🟢 A* explored {saved_nodes} FEWER nodes ({percent_saved:.0f}% more efficient!)")
            print(f"      → A* uses heuristic to go directly toward the target")
        elif d_visited < a_visited:
            saved_nodes = a_visited - d_visited
            print(f"   🟢 Dijkstra explored {saved_nodes} FEWER nodes")
        else:
            print(f"   🟡 Both algorithms explored the same number of nodes")

        # Final verdict
        print(f"\n🏆 FINAL VERDICT:")
        if a_visited < d_visited:
            print(f"   ✅ A* is the WINNER! (Explores fewer nodes)")
            print(f"   💡 Best for: Emergency routing, real-time applications")
        elif d_visited < a_visited:
            print(f"   ✅ Dijkstra is the WINNER! (Explores fewer nodes)")
            print(f"   💡 Best for: Small graphs, guaranteed optimal paths")
        else:
            print(f"   ✅ Both algorithms are excellent for this route")

    # ==================== 7. AI PREDICTION ====================
    def show_ai_prediction(self):
        self.clear_screen()
        self.print_header("🤖 AI TRAFFIC PREDICTION")

        start = self.select_location("Route from:")
        end = self.select_location("Route to:")

        current_hour = datetime.now().hour

        print(f"\n📍 ROUTE: {start} → {end}")
        print(f"🕐 Current time: {current_hour}:00")

        print(f"\n📊 HOURLY TRAFFIC PREDICTION:")
        print(f"   {'Hour':<12} {'Traffic Factor':<18} {'Status'}")
        print(f"   " + "-" * 50)

        traffic_hours = [
            (6, "Morning Start", 1.2),
            (7, "Morning Rush", 1.5),
            (8, "Peak Morning", 1.5),
            (9, "Late Morning", 1.3),
            (12, "Afternoon", 1.0),
            (15, "Evening Start", 1.2),
            (17, "Evening Rush", 1.4),
            (18, "Peak Evening", 1.4),
            (20, "Evening End", 1.1),
            (22, "Night", 0.8),
        ]

        for hour, name, factor in traffic_hours:
            marker = "👉" if hour <= current_hour < hour + 2 else "  "
            if factor >= 1.4:
                status = "🚨 HEAVY - Avoid if possible"
            elif factor >= 1.2:
                status = "⚠️ Moderate - Expect delays"
            elif factor >= 0.9:
                status = "✅ Light - Normal travel"
            else:
                status = "🌟 Very Light - Perfect time"
            print(f"   {marker} {hour:00}-{(hour + 2):00}   {factor:.1f}x            {status}")

        print(f"\n💡 AI RECOMMENDATION:")
        if 7 <= current_hour <= 9:
            print(f"   • It's MORNING RUSH HOUR (7-9 AM)")
            print(f"   • Recommendation: Use Metro or delay travel until 10 AM")
        elif 17 <= current_hour <= 20:
            print(f"   • It's EVENING RUSH HOUR (5-8 PM)")
            print(f"   • Recommendation: Use Metro or wait until 8 PM")
        elif current_hour <= 5 or current_hour >= 22:
            print(f"   • It's NIGHT TIME")
            print(f"   • Recommendation: Perfect time for travel - light traffic")
        else:
            print(f"   • It's NORMAL HOURS")
            print(f"   • Recommendation: Good time to travel")

        print("\n" + "🤖" * 40)
        print("✅ AI prediction complete")
        print("🤖" * 40)

    # ==================== 8. NETWORK INFO ====================
    def show_network_info(self):
        self.clear_screen()
        self.print_header("🌐 NETWORK INFORMATION")

        print(f"\n📊 STATISTICS:")
        print(f"   • Total locations: {len(self.network.nodes)}")
        print(f"   • Critical facilities (Hospitals): {', '.join(self.network.critical_facilities)}")

        print(f"\n📍 ALL LOCATIONS ({len(self.nodes)} total):")
        print("-" * 50)

        # تقسيم لـ 3 أعمدة
        areas_list = []
        facilities_list = []

        for node in self.nodes:
            pop = self.network.population.get(node, 0)
            critical = "🏥" if node in self.network.critical_facilities else ""
            if pop > 0:
                areas_list.append(f"   {critical} {node:<30} ({pop:,} people)")
            else:
                facilities_list.append(f"   {critical} {node:<30}")

        print("   [AREAS]:")
        for area in areas_list[:10]:
            print(area)
        print("   ...")

        print("\n   [FACILITIES]:")
        for fac in facilities_list:
            print(fac)

        print(f"\n🚦 TRAFFIC MULTIPLIERS:")
        print(f"   • Morning (7-9 AM): 1.5x")
        print(f"   • Afternoon (12-3 PM): 1.0x")
        print(f"   • Evening (5-8 PM): 1.4x")
        print(f"   • Night (10 PM-5 AM): 0.8x")

    # ==================== MAIN MENU ====================
    def run(self):
        while True:
            print("\n" + "█" * 65)
            print("🏙️  SMART CAIRO TRANSPORTATION SYSTEM  🏙️")
            print("█" * 65)
            print("\n📋 MAIN MENU:")
            print("   " + "-" * 50)
            print("   1. 🛣️  SHOW ALL PATHS")
            print("   2. ⭐ BEST ROUTE (without ML)")
            print("   3. ⭐ BEST ROUTE (with ML & Analysis)")
            print("   4. 🚑 EMERGENCY ROUTE (Ambulance)")
            print("   5. 🌲 SHOW MST GRAPH")
            print("   6. 📊 COMPARE A* vs DIJKSTRA")
            print("   7. 🤖 AI TRAFFIC PREDICTION")
            print("   8. 🌐 SHOW NETWORK INFO")
            print("   0. ❌ EXIT")
            print("   " + "-" * 50)

            choice = input("\n👉 Enter your choice (0-8): ").strip()

            if choice == "1":
                self.show_all_paths()
            elif choice == "2":
                self.show_best_path_without_ml()
            elif choice == "3":
                self.show_best_path_with_ml()
            elif choice == "4":
                self.show_emergency_route()
            elif choice == "5":
                self.show_mst_graph()
            elif choice == "6":
                self.compare_astar_dijkstra()
            elif choice == "7":
                self.show_ai_prediction()
            elif choice == "8":
                self.show_network_info()
            elif choice == "0":
                print("\n✅ Thank you for using Smart Cairo Transport System!")
                print("👋 Goodbye!\n")
                break
            else:
                print("❌ Invalid choice. Please enter 0-8")

            input("\n📌 Press Enter to continue...")


if __name__ == "__main__":
    cli = TransportCLI()
    cli.run()
