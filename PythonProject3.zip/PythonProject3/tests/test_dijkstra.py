# tests/test_dijkstra.py
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from algorithms.core_data import CairoTransportData
from algorithms.dijkstra import DijkstraRouter


class TestDijkstra(unittest.TestCase):

    def setUp(self):
        """Set up test network"""
        self.network = CairoTransportData()
        self.network.build_cairo_network()

    def test_shortest_path_exists(self):
        """Test that shortest path exists between nodes"""
        path, time, _ = DijkstraRouter.find_shortest_path(self.network, "NasrCity", "Giza")
        self.assertIsNotNone(path)
        self.assertGreater(time, 0)
        self.assertEqual(path[0], "NasrCity")
        self.assertEqual(path[-1], "Giza")

    def test_same_start_end(self):
        """Test path from node to itself"""
        path, time, _ = DijkstraRouter.find_shortest_path(self.network, "NasrCity", "NasrCity")
        self.assertEqual(len(path), 1)
        self.assertEqual(time, 0)

    def test_path_length(self):
        """Test path length is reasonable"""
        path, time, _ = DijkstraRouter.find_shortest_path(self.network, "Helwan", "Downtown")
        self.assertLess(time, 100)  # Should be reasonable
        self.assertGreater(len(path), 1)

    def test_time_dependent_routing(self):
        """Test time-dependent routing works"""
        path_night, time_night, _ = DijkstraRouter.time_dependent_shortest_path(
            self.network, "NasrCity", "Giza", "night")
        path_morning, time_morning, _ = DijkstraRouter.time_dependent_shortest_path(
            self.network, "NasrCity", "Giza", "morning")

        # Morning should be slower due to traffic
        self.assertGreaterEqual(time_morning, time_night)

    def test_invalid_nodes(self):
        """Test handling of invalid nodes"""
        path, time, _ = DijkstraRouter.find_shortest_path(self.network, "InvalidCity", "Giza")
        self.assertIsNone(path)
        self.assertEqual(time, float('inf'))


if __name__ == '__main__':
    unittest.main()