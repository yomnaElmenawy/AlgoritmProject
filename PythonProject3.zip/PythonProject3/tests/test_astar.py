# tests/test_astar.py
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from algorithms.core_data import CairoTransportData
from algorithms.astar import AStarRouter


class TestAStar(unittest.TestCase):

    def setUp(self):
        self.network = CairoTransportData()
        self.network.build_cairo_network()

    def test_emergency_routing(self):
        """Test emergency routing works"""
        path, time, _ = AStarRouter.emergency_routing(self.network, "Helwan", "Downtown")
        self.assertIsNotNone(path)
        self.assertGreater(time, 0)

    def test_emergency_to_critical(self):
        """Test emergency routing to critical facility"""
        # Downtown is a critical facility (hospital)
        path, time, _ = AStarRouter.emergency_routing(self.network, "NewCairo", "Downtown")
        self.assertIsNotNone(path)

    def test_emergency_with_traffic(self):
        """Test emergency routing with traffic conditions"""
        path_night, time_night, _ = AStarRouter.emergency_with_traffic(
            self.network, "NasrCity", "Downtown", "night")
        path_morning, time_morning, _ = AStarRouter.emergency_with_traffic(
            self.network, "NasrCity", "Downtown", "morning")

        # Morning traffic should increase response time
        self.assertGreaterEqual(time_morning, time_night)


if __name__ == '__main__':
    unittest.main()