# tests/test_mst.py
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
from algorithms.core_data import CairoTransportData
from algorithms.mst import MinimumSpanningTree


class TestMST(unittest.TestCase):

    def setUp(self):
        self.network = CairoTransportData()
        self.network.build_cairo_network()

    def test_kruskal_returns_edges(self):
        """Test Kruskal returns edges"""
        result = MinimumSpanningTree.kruskal_with_constraints(self.network)
        self.assertIn('edges', result)
        self.assertIn('total_cost', result)
        self.assertGreater(len(result['edges']), 0)

    def test_mst_connects_all_nodes(self):
        """Test MST connects all nodes"""
        result = MinimumSpanningTree.kruskal_with_constraints(self.network)
        # Number of edges in MST = number of nodes - 1
        expected_edges = len(self.network.nodes) - 1
        self.assertEqual(len(result['edges']), expected_edges)

    def test_prim_returns_result(self):
        """Test Prim algorithm works"""
        result = MinimumSpanningTree.prim_with_population_priority(self.network)
        self.assertIn('total_cost', result)
        self.assertGreater(result['total_cost'], 0)


if __name__ == '__main__':
    unittest.main()