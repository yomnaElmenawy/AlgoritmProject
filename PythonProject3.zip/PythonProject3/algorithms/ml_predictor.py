# algorithms/ml_predictor.py
import random
from datetime import datetime
from collections import defaultdict


class TrafficPredictor:
    """
    Simple Machine Learning model to predict traffic and suggest best times
    Uses historical data patterns to avoid congestion
    """

    def __init__(self):
        # Historical traffic data (hour -> average traffic factor)
        self.historical_data = {
            6: 1.2,  # 6 AM - light traffic
            7: 1.5,  # 7 AM - morning rush starts
            8: 1.8,  # 8 AM - peak morning rush
            9: 1.7,  # 9 AM - still busy
            10: 1.3,  # 10 AM - moderate
            11: 1.2,  # 11 AM - moderate
            12: 1.1,  # 12 PM - lunch time
            13: 1.2,  # 1 PM
            14: 1.3,  # 2 PM
            15: 1.4,  # 3 PM
            16: 1.6,  # 4 PM - evening rush starts
            17: 1.9,  # 5 PM - peak evening rush
            18: 2.0,  # 6 PM - worst traffic
            19: 1.7,  # 7 PM - still busy
            20: 1.3,  # 8 PM - calming down
            21: 1.1,  # 9 PM - normal
            22: 1.0  # 10 PM - light
        }

        # Learning data (will be updated based on user choices)
        self.learned_patterns = defaultdict(lambda: defaultdict(int))

    def predict_traffic_at_time(self, hour):
        """Predict traffic factor for a given hour"""
        if hour in self.historical_data:
            return self.historical_data[hour]
        elif hour < 6:
            return 0.9  # Very early morning
        elif hour > 22:
            return 0.8  # Late night
        else:
            return 1.2  # Default

    def predict_best_departure_time(self, route_start, route_end, current_hour=None):
        """
        Predict best time to depart to avoid traffic
        Returns: (best_hour, predicted_traffic_factor, recommendation)
        """
        if current_hour is None:
            current_hour = datetime.now().hour

        # Test different departure times
        best_hour = current_hour
        best_factor = float('inf')

        for offset in range(-2, 5):  # Check 2 hours before to 4 hours after
            test_hour = (current_hour + offset) % 24
            factor = self.predict_traffic_at_time(test_hour)

            # Apply learning adjustments if available
            route_key = f"{route_start}_{route_end}"
            if route_key in self.learned_patterns and test_hour in self.learned_patterns[route_key]:
                factor *= (1 - self.learned_patterns[route_key][test_hour] / 100)

            if factor < best_factor:
                best_factor = factor
                best_hour = test_hour

        # Generate recommendation text
        if best_hour == current_hour:
            recommendation = "Leave now - current traffic is optimal"
        elif best_hour > current_hour:
            diff = best_hour - current_hour
            recommendation = f"Wait {diff} hour(s) for better traffic"
        else:
            diff = current_hour - best_hour
            recommendation = f"Should have left {diff} hour(s) ago"

        return best_hour, best_factor, recommendation

    def learn_from_trip(self, route_start, route_end, hour_taken, actual_time, predicted_time):
        """
        Learn from actual trip data to improve predictions
        """
        route_key = f"{route_start}_{route_end}"
        error = (actual_time - predicted_time) / predicted_time

        # Adjust pattern based on error
        adjustment = min(10, max(-10, error * 5))
        self.learned_patterns[route_key][hour_taken] += adjustment

    def get_traffic_warning(self, hour):
        """Get warning message about traffic conditions"""
        factor = self.predict_traffic_at_time(hour)

        if factor >= 1.8:
            return "🚨 HEAVY TRAFFIC! Consider waiting or using public transport"
        elif factor >= 1.4:
            return "⚠️ Moderate traffic - allow extra time"
        elif factor >= 1.1:
            return "✅ Light traffic - good time to travel"
        else:
            return "🌟 Very low traffic - perfect time!"


class RouteOptimizerML:
    """
    Machine Learning based route optimizer
    Learns which routes are best under different conditions
    """

    def __init__(self):
        self.route_history = defaultdict(list)
        self.learned_best_routes = {}

    def record_route_performance(self, start, end, transport_mode, traffic_factor, time_taken):
        """
        Record how a route performed
        """
        key = f"{start}_{end}_{transport_mode}"
        self.route_history[key].append({
            'traffic_factor': traffic_factor,
            'time_taken': time_taken,
            'timestamp': datetime.now()
        })

        # Update learned best routes (simple average)
        avg_time = sum(r['time_taken'] for r in self.route_history[key]) / len(self.route_history[key])
        self.learned_best_routes[key] = avg_time

    def predict_route_time(self, start, end, transport_mode, traffic_factor):
        """
        Predict route time based on learned data
        """
        key = f"{start}_{end}_{transport_mode}"

        if key in self.learned_best_routes:
            base_time = self.learned_best_routes[key]
            return base_time * traffic_factor
        else:
            # No data yet - return None to use Dijkstra
            return None

    def suggest_alternative_transport(self, start, end, current_traffic):
        """
        Suggest alternative transport modes based on traffic conditions
        """
        suggestions = []

        if current_traffic >= 1.5:
            suggestions.append({
                'mode': 'Metro',
                'reason': 'Avoids road traffic completely',
                'saved_time_percent': 40
            })
            suggestions.append({
                'mode': 'Bus (Priority Lane)',
                'reason': 'Has dedicated bus lanes',
                'saved_time_percent': 25
            })

        if current_traffic >= 1.8:
            suggestions.append({
                'mode': 'Bike',
                'reason': 'No traffic impact',
                'saved_time_percent': 60
            })

        return suggestions