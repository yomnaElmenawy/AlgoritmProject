# algorithms/greedy.py
class TrafficSignalOptimizer:
    """Greedy algorithm for real-time traffic signal optimization"""

    @staticmethod
    def optimize_signal_timing(intersections, traffic_flow, cycle_time=90):
        """
        Greedy approach for real-time traffic signal optimization
        Uses real traffic flow data
        """
        total_flow = sum(traffic_flow.values())

        if total_flow == 0:
            return {inter: cycle_time / len(intersections) for inter in intersections}

        schedule = {}
        for intersection in intersections:
            flow = traffic_flow.get(intersection, 0)
            green_time = (flow / total_flow) * cycle_time
            schedule[intersection] = round(green_time, 1)

        return {
            "green_time_per_intersection": schedule,
            "total_cycle_time": cycle_time,
            "algorithm": "Greedy - Proportional Allocation"
        }

    @staticmethod
    def optimize_with_real_traffic(network, time_of_day):
        """
        Optimize traffic signals using real traffic data from PDF
        """
        traffic_data = network.get_traffic_data()

        # Extract intersections from traffic data
        intersections = set()
        traffic_flow = {}

        for (u, v), data in traffic_data.items():
            intersections.add(u)
            intersections.add(v)
            # Get flow based on time of day
            flow = data.get(time_of_day, data.get("afternoon", 500))
            traffic_flow[u] = traffic_flow.get(u, 0) + flow / 2
            traffic_flow[v] = traffic_flow.get(v, 0) + flow / 2

        return TrafficSignalOptimizer.optimize_signal_timing(list(intersections), traffic_flow, 90)

    @staticmethod
    def emergency_vehicle_preemption(intersections, emergency_route, traffic_flow, congestion_level):
        """
        Priority-based system for managing emergency vehicle preemption
        during high congestion periods
        """
        congestion_multiplier = {"low": 1.0, "medium": 1.5, "high": 2.0}
        multiplier = congestion_multiplier.get(congestion_level, 1.0)

        preemption_schedule = []

        for i, intersection in enumerate(emergency_route):
            flow = traffic_flow.get(intersection, 50)
            clearance_time = min(30, max(10, int(flow * multiplier / 10)))

            preemption_schedule.append({
                "intersection": intersection,
                "sequence_order": i + 1,
                "preemption_time_seconds": clearance_time,
                "priority_level": "MAXIMUM"
            })

            if i < len(emergency_route) - 1:
                next_intersection = emergency_route[i + 1]
                preemption_schedule.append({
                    "intersection": next_intersection,
                    "preparation": True,
                    "estimated_ready_time": clearance_time
                })

        return {
            "preemption_schedule": preemption_schedule,
            "total_emergency_clearance_time": sum(
                p.get("preemption_time_seconds", 0) for p in preemption_schedule if "preemption_time_seconds" in p),
            "congestion_level": congestion_level,
            "algorithm": "Greedy Priority Preemption"
        }

    @staticmethod
    def analyze_optimal_vs_suboptimal(network):
        """
        Analyze cases where greedy approach provides optimal and suboptimal solutions
        in the Egyptian context (Cairo traffic patterns)
        """
        analysis = {
            "optimal_cases": [
                {
                    "scenario": "Low congestion, independent intersections",
                    "reason": "No interference between intersections, greedy gives optimal proportional allocation"
                },
                {
                    "scenario": "Single emergency vehicle with clear route",
                    "reason": "No conflicting priorities, preemption is clearly optimal"
                },
                {
                    "scenario": "Rush hour with clear patterns",
                    "reason": "Cairo's predictable rush hours (7-9 AM, 5-8 PM) allow greedy optimization"
                }
            ],
            "suboptimal_cases": [
                {
                    "scenario": "High congestion with cascading effects",
                    "reason": "Greedy doesn't account for future traffic buildup at subsequent intersections"
                },
                {
                    "scenario": "Multiple simultaneous emergency vehicles",
                    "reason": "Greedy prioritizes first vehicle, may block secondary emergency routes"
                },
                {
                    "scenario": "Ramadan or holiday traffic patterns",
                    "reason": "Unusual patterns break the greedy assumptions"
                }
            ],
            "recommendation": "Use greedy for real-time response, but combine with DP for long-term scheduling"
        }

        # Add Cairo-specific insights
        analysis["cairo_specific"] = {
            "peak_hours": "7-9 AM and 5-8 PM",
            "worst_corridor": "6th October Bridge to Downtown",
            "best_alternative": "Use metro during peak hours"
        }

        return analysis