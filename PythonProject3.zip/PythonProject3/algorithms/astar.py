import heapq


class AStarRouter:
    """A* search algorithm for emergency vehicle routing"""

    @staticmethod
    def _heuristic(node, target, network):
        """Heuristic function for A*"""
        if node == target:
            return 0
        if target in network.critical_facilities:
            if node in network.critical_facilities:
                return 5
            return 10
        return abs(hash(node) - hash(target)) % 20

    @staticmethod
    def emergency_routing(network, start, end):
        """A* algorithm for emergency vehicle routing"""
        if start not in network.nodes or end not in network.nodes:
            return None, float('inf'), 0

        open_set = [(0, start)]
        g_score = {node: float('inf') for node in network.nodes}
        g_score[start] = 0
        f_score = {node: float('inf') for node in network.nodes}
        f_score[start] = AStarRouter._heuristic(start, end, network)
        previous = {node: None for node in network.nodes}
        visited_count = 0

        while open_set:
            _, current = heapq.heappop(open_set)
            visited_count += 1

            if current == end:
                break

            for neighbor, weight in network.get_neighbors(current):
                tentative_g = g_score[current] + weight

                if tentative_g < g_score[neighbor]:
                    previous[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + AStarRouter._heuristic(neighbor, end, network)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

        if g_score[end] == float('inf'):
            return None, float('inf'), visited_count

        path = []
        node = end
        while node is not None:
            path.append(node)
            node = previous[node]
        path.reverse()

        return path, g_score[end], visited_count

    @staticmethod
    def emergency_with_traffic(network, start, end, time_of_day):
        """Emergency routing with traffic conditions"""
        traffic_factor = network.apply_traffic_factor(time_of_day)

        class TrafficAwareNetwork:
            def __init__(self, original, factor):
                self.original = original
                self.factor = factor

            def get_neighbors(self, node):
                return [(n, w * self.factor) for n, w in self.original.get_neighbors(node)]

            def critical_facilities(self):
                return self.original.critical_facilities

        temp_network = TrafficAwareNetwork(network, traffic_factor)

        open_set = [(0, start)]
        g_score = {node: float('inf') for node in network.nodes}
        g_score[start] = 0
        f_score = {node: float('inf') for node in network.nodes}
        f_score[start] = AStarRouter._heuristic(start, end, network)
        previous = {node: None for node in network.nodes}

        while open_set:
            _, current = heapq.heappop(open_set)
            if current == end:
                break
            for neighbor, weight in temp_network.get_neighbors(current):
                tentative_g = g_score[current] + weight
                if tentative_g < g_score[neighbor]:
                    previous[neighbor] = current
                    g_score[neighbor] = tentative_g
                    f_score[neighbor] = tentative_g + AStarRouter._heuristic(neighbor, end, network)
                    heapq.heappush(open_set, (f_score[neighbor], neighbor))

        if g_score[end] == float('inf'):
            return None, float('inf'), traffic_factor

        path = []
        node = end
        while node is not None:
            path.append(node)
            node = previous[node]
        path.reverse()

        return path, g_score[end], traffic_factor