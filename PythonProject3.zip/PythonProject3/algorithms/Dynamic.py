# algorithms/Dynamic.py
class PublicTransitScheduler:
    """Dynamic Programming solutions for public transportation optimization"""

    @staticmethod
    def optimize_bus_schedule(bus_lines, total_buses, time_slots):
        """
        DP solution for optimal scheduling of public transportation vehicles
        """
        dp = [[0] * (time_slots + 1) for _ in range(total_buses + 1)]
        schedule = [[0] * (time_slots + 1) for _ in range(total_buses + 1)]

        for buses in range(1, total_buses + 1):
            for slots in range(1, time_slots + 1):
                dp[buses][slots] = dp[buses][slots - 1]
                schedule[buses][slots] = 0

                if slots <= len(bus_lines):
                    passengers = bus_lines[slots - 1]
                    with_bus = dp[buses - 1][slots - 1] + passengers
                    if with_bus > dp[buses][slots]:
                        dp[buses][slots] = with_bus
                        schedule[buses][slots] = 1

        allocation = []
        b, s = total_buses, time_slots
        while b > 0 and s > 0:
            if schedule[b][s] == 1:
                allocation.append(s - 1)
                b -= 1
                s -= 1
            else:
                s -= 1

        return {
            "max_passengers_served": dp[total_buses][time_slots],
            "allocated_time_slots": sorted(allocation),
            "buses_used": len(allocation),
            "algorithm": "Dynamic Programming - 0/1 Knapsack"
        }

    @staticmethod
    def optimize_metro_schedule(network):
        """
        Optimize metro scheduling using real data from PDF
        """
        metro_lines = network.get_metro_lines()

        result = {}
        for line_id, data in metro_lines.items():
            # Calculate optimal frequency based on passengers
            passengers = data["daily_passengers"]
            optimal_frequency = max(3, min(10, int(passengers / 200000)))

            result[line_id] = {
                "name": data["name"],
                "stations": data["stations"],
                "daily_passengers": passengers,
                "recommended_frequency_minutes": optimal_frequency,
                "trains_needed": max(5, int(passengers / 100000))
            }

        return result

    @staticmethod
    def optimize_bus_routes(network):
        """
        Optimize bus routes using real data from PDF
        """
        bus_routes = network.get_bus_routes()

        result = {}
        for route_id, data in bus_routes.items():
            passengers = data["daily_passengers"]
            buses = data["buses"]

            # Calculate efficiency
            efficiency = passengers / buses

            result[route_id] = {
                "stops": data["stops"],
                "daily_passengers": passengers,
                "buses_assigned": buses,
                "efficiency": round(efficiency, 0),
                "recommendation": "Increase buses" if efficiency > 1500 else "Optimal" if efficiency > 1000 else "Reduce buses"
            }

        return result

    @staticmethod
    def road_maintenance_resource_allocation(road_conditions, budget, maintenance_costs):
        """
        DP for resource allocation problem for road maintenance
        """
        n = len(road_conditions)
        dp = [[0] * (budget + 1) for _ in range(n + 1)]
        selected = [[False] * (budget + 1) for _ in range(n + 1)]

        for i in range(1, n + 1):
            road_id, condition, priority = road_conditions[i - 1]
            cost = maintenance_costs[i - 1]
            value = condition * priority

            for b in range(budget + 1):
                dp[i][b] = dp[i - 1][b]

                if cost <= b:
                    with_maintenance = dp[i - 1][b - cost] + value
                    if with_maintenance > dp[i][b]:
                        dp[i][b] = with_maintenance
                        selected[i][b] = True

        roads_to_maintain = []
        b = budget
        for i in range(n, 0, -1):
            if selected[i][b]:
                roads_to_maintain.append(road_conditions[i - 1][0])
                b -= maintenance_costs[i - 1]

        return {
            "max_condition_improvement": dp[n][budget],
            "roads_to_maintain": roads_to_maintain,
            "total_cost": budget - b,
            "algorithm": "Dynamic Programming - Knapsack"
        }

    @staticmethod
    def memoized_route_planning(network, start, end, memo=None):
        """Apply memoization techniques to improve route planning performance"""
        if memo is None:
            memo = {}

        key = (start, end)
        if key in memo:
            return memo[key]

        from .dijkstra import DijkstraRouter
        path, time, _ = DijkstraRouter.find_shortest_path(network, start, end)

        memo[key] = (path, time)
        return memo[key]