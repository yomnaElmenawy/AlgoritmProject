# algorithms/core_data.py
class CairoTransportData:
    """Cairo Transportation Network with all 25 nodes connected"""

    def __init__(self):
        self.graph = {}
        self.nodes = set()
        self.population = {}
        self.critical_facilities = set()

        # Traffic multipliers based on PDF data (Morning Peak, Afternoon, Evening Peak, Night)
        self.traffic_multiplier = {
            "morning": 1.5,  # Morning Peak (7-9 AM)
            "afternoon": 1.0,  # Afternoon (12-3 PM)
            "evening": 1.4,  # Evening Peak (5-8 PM)
            "night": 0.8  # Night (10 PM - 5 AM)
        }

        # ===== Areas from PDF (15 areas) =====
        self.areas = {
            1: {"name": "Maadi", "population": 250000, "type": "Residential", "lat": 29.96, "lon": 31.25},
            2: {"name": "Nasr City", "population": 500000, "type": "Mixed", "lat": 30.06, "lon": 31.34},
            3: {"name": "Downtown Cairo", "population": 100000, "type": "Business", "lat": 30.04, "lon": 31.24},
            4: {"name": "New Cairo", "population": 300000, "type": "Residential", "lat": 30.03, "lon": 31.47},
            5: {"name": "Heliopolis", "population": 200000, "type": "Mixed", "lat": 30.09, "lon": 31.32},
            6: {"name": "Zamalek", "population": 50000, "type": "Residential", "lat": 30.06, "lon": 31.22},
            7: {"name": "6th October City", "population": 400000, "type": "Mixed", "lat": 29.93, "lon": 30.98},
            8: {"name": "Giza", "population": 550000, "type": "Mixed", "lat": 29.99, "lon": 31.21},
            9: {"name": "Mohandessin", "population": 180000, "type": "Business", "lat": 30.05, "lon": 31.20},
            10: {"name": "Dokki", "population": 220000, "type": "Mixed", "lat": 30.03, "lon": 31.21},
            11: {"name": "Shubra", "population": 450000, "type": "Residential", "lat": 30.11, "lon": 31.24},
            12: {"name": "Helwan", "population": 350000, "type": "Industrial", "lat": 29.85, "lon": 31.33},
            13: {"name": "New Administrative Capital", "population": 50000, "type": "Government", "lat": 30.02,
                 "lon": 31.80},
            14: {"name": "Al Rehab", "population": 120000, "type": "Residential", "lat": 30.06, "lon": 31.49},
            15: {"name": "Sheikh Zayed", "population": 150000, "type": "Residential", "lat": 30.01, "lon": 30.94}
        }

        # ===== Important Facilities from PDF (10 facilities) =====
        self.facilities = {
            "F1": {"name": "Cairo International Airport", "type": "Airport", "lat": 30.11, "lon": 31.41},
            "F2": {"name": "Ramses Railway Station", "type": "Transit Hub", "lat": 30.06, "lon": 31.25},
            "F3": {"name": "Cairo University", "type": "Education", "lat": 30.03, "lon": 31.21},
            "F4": {"name": "Al-Azhar University", "type": "Education", "lat": 30.05, "lon": 31.26},
            "F5": {"name": "Egyptian Museum", "type": "Tourism", "lat": 30.05, "lon": 31.23},
            "F6": {"name": "Cairo International Stadium", "type": "Sports", "lat": 30.07, "lon": 31.30},
            "F7": {"name": "Smart Village", "type": "Business", "lat": 30.07, "lon": 30.97},
            "F8": {"name": "Cairo Festival City", "type": "Commercial", "lat": 30.03, "lon": 31.40},
            "F9": {"name": "Qasr El Aini Hospital", "type": "Medical", "lat": 30.03, "lon": 31.23},
            "F10": {"name": "Maadi Military Hospital", "type": "Medical", "lat": 29.95, "lon": 31.25}
        }

        # إضافة المناطق كـ nodes
        for area_id, data in self.areas.items():
            self.add_node(data["name"], data["population"], False)

        # إضافة المرافق كـ nodes
        for fac_id, data in self.facilities.items():
            is_critical = data["type"] == "Medical"
            self.add_node(data["name"], 0, is_critical)

    def add_node(self, node_id, population=0, is_critical=False):
        self.nodes.add(node_id)
        self.graph[node_id] = self.graph.get(node_id, [])
        self.population[node_id] = population
        if is_critical:
            self.critical_facilities.add(node_id)

    def add_edge(self, u, v, weight):
        self.graph.setdefault(u, []).append((v, weight))
        self.graph.setdefault(v, []).append((u, weight))

    def get_neighbors(self, node):
        return self.graph.get(node, [])

    def get_edge_weight(self, u, v):
        for neighbor, weight in self.graph.get(u, []):
            if neighbor == v:
                return weight
        return float('inf')

    def build_cairo_network(self):
        """Build FULLY CONNECTED Cairo network (ALL 25 nodes connected)"""

        # ================================================================
        # 1. CORE BACKBONE - يضمن اتصال كل المناطق الرئيسية
        # ================================================================
        main_backbone = [
            "6th October City",
            "Sheikh Zayed",
            "Smart Village",
            "Giza",
            "Dokki",
            "Downtown Cairo",
            "Mohandessin",
            "Zamalek",
            "Nasr City",
            "Heliopolis",
            "New Cairo",
            "Al Rehab",
            "New Administrative Capital"
        ]

        for i in range(len(main_backbone) - 1):
            self.add_edge(main_backbone[i], main_backbone[i + 1], 8.0)

        # ================================================================
        # 2. EXISTING ROADS from PDF
        # ================================================================
        existing_roads = [
            ("Maadi", "Downtown Cairo", 8.5),
            ("Maadi", "Giza", 6.2),
            ("Nasr City", "Downtown Cairo", 5.9),
            ("Nasr City", "Heliopolis", 4.0),
            ("Downtown Cairo", "Heliopolis", 6.1),
            ("Downtown Cairo", "Zamalek", 3.2),
            ("Downtown Cairo", "Mohandessin", 4.5),
            ("Downtown Cairo", "Dokki", 3.8),
            ("New Cairo", "Nasr City", 15.2),
            ("New Cairo", "Al Rehab", 5.3),
            ("Heliopolis", "Shubra", 7.9),
            ("Zamalek", "Mohandessin", 2.2),
            ("6th October City", "Giza", 24.5),
            ("6th October City", "Sheikh Zayed", 9.8),
            ("Giza", "Dokki", 3.3),
            ("Giza", "Helwan", 14.8),
            ("Mohandessin", "Dokki", 2.1),
            ("Dokki", "Shubra", 8.7),
            ("Shubra", "Ramses Railway Station", 3.6),
            ("Helwan", "Maadi", 12.7),
            ("New Administrative Capital", "New Cairo", 45.0),
            ("Al Rehab", "New Administrative Capital", 35.5),
            ("Sheikh Zayed", "6th October City", 9.8),
            ("Cairo International Airport", "Heliopolis", 7.5),
            ("Cairo International Airport", "Nasr City", 9.2),
            ("Ramses Railway Station", "Downtown Cairo", 2.5),
            ("Smart Village", "Sheikh Zayed", 8.3),
            ("Cairo Festival City", "New Cairo", 6.1)
        ]

        for u, v, w in existing_roads:
            self.add_edge(u, v, w)

        # ================================================================
        # 3. CRITICAL FACILITIES CONNECTIONS (مستشفيات - جامعات - معالم)
        # ================================================================

        # Hospitals (Critical Facilities - Red nodes)
        self.add_edge("Qasr El Aini Hospital", "Downtown Cairo", 1.8)
        self.add_edge("Maadi Military Hospital", "Maadi", 5.0)

        # Universities
        self.add_edge("Cairo University", "Dokki", 3.0)
        self.add_edge("Al-Azhar University", "Downtown Cairo", 2.0)

        # Tourism & Sports
        self.add_edge("Egyptian Museum", "Downtown Cairo", 1.5)
        self.add_edge("Cairo International Stadium", "Nasr City", 2.5)

        # ================================================================
        # 4. EXTRA CONNECTIONS FOR ISOLATED NODES
        # ================================================================

        # ربط Helwan بطرق إضافية
        self.add_edge("Helwan", "Maadi", 12.7)

        # ربط Shubra بشكل أفضل
        self.add_edge("Shubra", "Nasr City", 6.0)

        # ربط New Administrative Capital بطرق إضافية
        self.add_edge("New Administrative Capital", "Al Rehab", 35.5)

        # ربط Smart Village بطرق إضافية
        self.add_edge("Smart Village", "6th October City", 8.0)

        # ربط Al Rehab بشكل أفضل
        self.add_edge("Al Rehab", "Nasr City", 12.0)

        # ربط Zamalek بطرق إضافية
        self.add_edge("Zamalek", "Dokki", 4.0)

        # ربط Mohandessin بطرق إضافية
        self.add_edge("Mohandessin", "Giza", 5.0)

        # ================================================================
        # 5. FACILITIES TO MAIN NETWORK
        # ================================================================

        # Cairo Festival City connections
        self.add_edge("Cairo Festival City", "New Cairo", 6.1)
        self.add_edge("Cairo Festival City", "Al Rehab", 4.0)

        # Cairo International Airport extra connections
        self.add_edge("Cairo International Airport", "Heliopolis", 7.5)
        self.add_edge("Cairo International Airport", "Nasr City", 9.2)

        # Ramses Station extra connections
        self.add_edge("Ramses Railway Station", "Downtown Cairo", 2.5)
        self.add_edge("Ramses Railway Station", "Shubra", 3.6)

        return self

    def get_potential_roads(self):
        """Return potential new roads from PDF for MST"""
        return [
            ("Maadi", "New Cairo", 22.8),
            ("Maadi", "Al Rehab", 25.3),
            ("Nasr City", "New Administrative Capital", 48.2),
            ("Downtown Cairo", "New Administrative Capital", 56.7),
            ("Heliopolis", "New Cairo", 16.8),
            ("Zamalek", "Giza", 7.5),
            ("6th October City", "New Administrative Capital", 82.3),
            ("Mohandessin", "Shubra", 6.9),
            ("Dokki", "Smart Village", 27.4),
            ("Shubra", "New Administrative Capital", 62.1),
            ("Helwan", "Al Rehab", 30.5),
            ("Al Rehab", "Heliopolis", 18.2),
            ("Sheikh Zayed", "Mohandessin", 22.7),
            ("Cairo International Airport", "New Administrative Capital", 40.2),
            ("Smart Village", "Mohandessin", 26.8)
        ]

    def apply_traffic_factor(self, time_of_day):
        """Return traffic multiplier based on time of day"""
        return self.traffic_multiplier.get(time_of_day, 1.0)