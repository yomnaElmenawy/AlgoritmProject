import heapq


class DijkstraRouter:
    """Standard Dijkstra's algorithm for route planning"""

    @staticmethod
    def find_shortest_path(network, start, end):
        """
        Find shortest path between two neighborhoods
        Returns: (path, total_time, nodes_visited)
        """
        if start not in network.nodes or end not in network.nodes:
            return None, float('inf'), 0

        distances = {node: float('inf') for node in network.nodes}
        distances[start] = 0
        previous = {node: None for node in network.nodes}
        visited_count = 0

        pq = [(0, start)]

        while pq:
            current_dist, current = heapq.heappop(pq)
            visited_count += 1

            if current == end:
                break

            if current_dist > distances[current]:
                continue

            for neighbor, weight in network.get_neighbors(current):
                new_dist = current_dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    previous[neighbor] = current
                    heapq.heappush(pq, (new_dist, neighbor))

        # Reconstruct path
        if distances[end] == float('inf'):
            return None, float('inf'), visited_count

        path = []
        node = end
        while node is not None:
            path.append(node)
            node = previous[node]
        path.reverse()

        return path, distances[end], visited_count

    @staticmethod
    def time_dependent_shortest_path(network, start, end, time_of_day):
        """
        Modified shortest path accounting for time-varying traffic conditions
        """
        traffic_factor = network.apply_traffic_factor(time_of_day)

        # Apply traffic factor to edge weights
        class TimeAwareNetwork:
            def __init__(self, original, factor):
                self.original = original
                self.factor = factor

            def get_neighbors(self, node):
                return [(n, w * self.factor) for n, w in self.original.get_neighbors(node)]

            @property
            def nodes(self):
                return self.original.nodes

        temp_network = TimeAwareNetwork(network, traffic_factor)

        # Run Dijkstra on modified network
        distances = {node: float('inf') for node in network.nodes}
        distances[start] = 0
        previous = {node: None for node in network.nodes}
        pq = [(0, start)]

        while pq:
            current_dist, current = heapq.heappop(pq)
            if current == end:
                break
            if current_dist > distances[current]:
                continue
            for neighbor, weight in temp_network.get_neighbors(current):
                new_dist = current_dist + weight
                if new_dist < distances[neighbor]:
                    distances[neighbor] = new_dist
                    previous[neighbor] = current
                    heapq.heappush(pq, (new_dist, neighbor))

        # Reconstruct path
        if distances[end] == float('inf'):
            return None, float('inf'), traffic_factor

        path = []
        node = end
        while node is not None:
            path.append(node)
            node = previous[node]
        path.reverse()

        return path, distances[end], traffic_factor


# ============================================================
# NEW FUNCTION: Find all possible paths between two nodes
# ============================================================

def find_all_paths(network, start, end, max_paths=10):
    """
    Find all possible paths between start and end using DFS
    Returns list of (path, time) sorted by time (shortest first)

    Parameters:
    - network: CairoTransportData object
    - start: starting node name
    - end: destination node name
    - max_paths: maximum number of paths to return

    Returns:
    - List of tuples: [(path_list, total_time), ...]
    """
    all_paths = []

    def dfs(current, end, path, time_so_far, visited):
        """Depth First Search to find all paths"""
        # If we reached the destination, add this path
        if current == end:
            all_paths.append((path.copy(), time_so_far))
            return

        # Stop if we have enough paths
        if len(all_paths) >= max_paths * 2:
            return

        # Try all neighbors
        for neighbor, weight in network.get_neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                path.append(neighbor)
                dfs(neighbor, end, path, time_so_far + weight, visited)
                path.pop()
                visited.remove(neighbor)

    # Start DFS from start node
    dfs(start, end, [start], 0, {start})

    # Remove duplicate paths (same sequence of nodes)
    unique_paths = []
    seen_paths = set()

    for path, time_val in sorted(all_paths, key=lambda x: x[1]):
        path_key = tuple(path)
        if path_key not in seen_paths:
            seen_paths.add(path_key)
            unique_paths.append((path, time_val))

    # Return only the requested number of paths
    return unique_paths[:max_paths]


def find_all_paths_with_details(network, start, end, max_paths=10):
    """
    Find all paths with additional details like number of stops
    Returns list of dictionaries with full information
    """
    paths = find_all_paths(network, start, end, max_paths)

    results = []
    for path, time_val in paths:
        results.append({
            'path': path,
            'time': time_val,
            'stops': len(path),
            'path_string': ' → '.join(path)
        })

    return results