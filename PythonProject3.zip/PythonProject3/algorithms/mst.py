import heapq


class MinimumSpanningTree:
    """Kruskal's and Prim's algorithms for cost-efficient road network"""

    @staticmethod
    def find_disconnected_nodes(network):
        """
        Find nodes that are disconnected from the main network
        Returns list of disconnected nodes
        """
        if not network.nodes:
            return []

        # BFS to find connected component from first node
        start = list(network.nodes)[0]
        visited = set()
        stack = [start]

        while stack:
            node = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            for neighbor, _ in network.get_neighbors(node):
                if neighbor not in visited:
                    stack.append(neighbor)

        # Find disconnected nodes
        disconnected = set(network.nodes) - visited
        return list(disconnected)

    @staticmethod
    def kruskal_with_constraints(network):
        """
        Implement Kruskal's algorithm with constraints
        """
        edges = []

        for u in network.graph:
            for v, w in network.graph[u]:
                if u < v:
                    edges.append((w, u, v))

        edges.sort()

        parent = {node: node for node in network.nodes}

        def find(node):
            while parent[node] != node:
                parent[node] = parent[parent[node]]
                node = parent[node]
            return node

        def union(u, v):
            ru, rv = find(u), find(v)
            if ru == rv:
                return False
            parent[ru] = rv
            return True

        mst_edges = []
        total_cost = 0
        critical_connected = set()

        for weight, u, v in edges:
            if union(u, v):
                mst_edges.append((u, v, weight))
                total_cost += weight

                if u in network.critical_facilities:
                    critical_connected.add(u)
                if v in network.critical_facilities:
                    critical_connected.add(v)

                if len(mst_edges) == len(network.nodes) - 1:
                    break

        return {
            "edges": mst_edges,
            "total_cost": round(total_cost, 1),
            "critical_facilities_connected": len(critical_connected),
            "algorithm": "Kruskal"
        }

    @staticmethod
    def prim_with_population_priority(network):
        """
        Prim's algorithm prioritizing connections between high-population areas
        """
        if not network.nodes:
            return {
                "edges": [],
                "total_cost": 0,
                "algorithm": "Prim"
            }

        # Start from highest population node
        start = (
            max(network.population.items(), key=lambda x: x[1])[0]
            if network.population
            else list(network.nodes)[0]
        )

        visited = set()
        mst_edges = []
        total_cost = 0

        pq = [(0, start, None, 0)]

        while pq and len(visited) < len(network.nodes):
            priority_cost, node, parent, real_weight = heapq.heappop(pq)

            if node in visited:
                continue

            visited.add(node)

            if parent is not None:
                mst_edges.append((parent, node, real_weight))
                total_cost += real_weight

            for neighbor, weight in network.get_neighbors(node):
                if neighbor not in visited:
                    adjusted_weight = weight
                    if neighbor in network.population:
                        pop = network.population[neighbor]
                        if pop > 400000:
                            adjusted_weight = weight * 0.7
                    heapq.heappush(pq, (adjusted_weight, neighbor, node, weight))

        return {
            "edges": mst_edges,
            "total_cost": round(total_cost, 1),
            "algorithm": "Prim with Population Priority"
        }