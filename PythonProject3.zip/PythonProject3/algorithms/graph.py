# algorithms/graph.py
from typing import Dict, List, Tuple, Optional
import json


class Graph:
    """Graph implementation for transportation network"""

    def __init__(self):
        self.adjacency: Dict[str, List[Tuple[str, float]]] = {}
        self.nodes: set = set()
        self.node_attributes: Dict[str, dict] = {}

    def add_node(self, node_id: str, **attributes):
        """Add a node to the graph"""
        if node_id not in self.adjacency:
            self.adjacency[node_id] = []
            self.nodes.add(node_id)
            self.node_attributes[node_id] = attributes

    def add_edge(self, u: str, v: str, weight: float, **attributes):
        """Add an edge to the graph (undirected)"""
        if u not in self.adjacency:
            self.add_node(u)
        if v not in self.adjacency:
            self.add_node(v)

        self.adjacency[u].append((v, weight))
        self.adjacency[v].append((u, weight))

        # Store edge attributes if needed
        if 'edges_attr' not in self.node_attributes:
            self.node_attributes['edges_attr'] = {}
        self.node_attributes['edges_attr'][(u, v)] = attributes

    def get_neighbors(self, node: str) -> List[Tuple[str, float]]:
        """Get all neighbors of a node"""
        return self.adjacency.get(node, [])

    def get_edge_weight(self, u: str, v: str) -> float:
        """Get weight of edge between u and v"""
        for neighbor, weight in self.adjacency.get(u, []):
            if neighbor == v:
                return weight
        return float('inf')

    def load_from_json(self, filepath: str):
        """Load graph from JSON file"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)

        for node in data.get('nodes', []):
            self.add_node(node['id'], **node.get('attributes', {}))

        for edge in data.get('edges', []):
            self.add_edge(edge['from'], edge['to'], edge['weight'], **edge.get('attributes', {}))

    def save_to_json(self, filepath: str):
        """Save graph to JSON file"""
        data = {
            'nodes': [{'id': node, 'attributes': self.node_attributes.get(node, {})} for node in self.nodes],
            'edges': []
        }

        # Track added edges to avoid duplicates
        added = set()
        for u in self.adjacency:
            for v, w in self.adjacency[u]:
                if (u, v) not in added and (v, u) not in added:
                    data['edges'].append({'from': u, 'to': v, 'weight': w})
                    added.add((u, v))

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2)

    @property
    def num_nodes(self) -> int:
        return len(self.nodes)

    @property
    def num_edges(self) -> int:
        count = 0
        seen = set()
        for u in self.adjacency:
            for v, _ in self.adjacency[u]:
                if (u, v) not in seen and (v, u) not in seen:
                    count += 1
                    seen.add((u, v))
        return count