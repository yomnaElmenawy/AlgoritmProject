# visualization/map_draw.py
import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.patches import FancyBboxPatch
import numpy as np


class CairoMapVisualizer:
    """Visualize Cairo transportation network"""

    def __init__(self):
        self.graph = nx.Graph()
        self.pos = {}
        self.node_colors = {}

    def build_from_network(self, network):
        """Build NetworkX graph from CairoTransportData"""
        self.graph.clear()

        # Define positions for Cairo neighborhoods (approximate coordinates)
        positions = {
            "NasrCity": (10, 15),
            "Downtown": (5, 10),
            "Giza": (2, 8),
            "Maadi": (7, 5),
            "Helwan": (8, 2),
            "NewCairo": (15, 12),
            "Imbaba": (3, 9),
            "Mohandiseen": (4, 9),
            "Abbassia": (8, 12),
            "Shubra": (4, 13),
            "Airport": (12, 14),
            "Heliopolis": (11, 14)
        }

        # Add nodes with positions
        for node in network.nodes:
            self.graph.add_node(node)
            if node in positions:
                self.pos[node] = positions[node]
            else:
                self.pos[node] = (np.random.random() * 15, np.random.random() * 15)

            # Color based on node type
            if node in network.critical_facilities:
                self.node_colors[node] = 'red'  # Critical facilities
            elif network.population.get(node, 0) > 400000:
                self.node_colors[node] = 'orange'  # High population
            else:
                self.node_colors[node] = 'lightblue'  # Normal

        # Add edges
        for u in network.graph:
            for v, w in network.graph[u]:
                if u < v:  # Add each edge once
                    self.graph.add_edge(u, v, weight=w)

    def draw_network(self, title="Cairo Transportation Network", highlight_path=None,
                     highlight_edges=None, save_path=None):
        """Draw the transportation network"""
        plt.figure(figsize=(14, 10))

        # Draw nodes
        node_colors_list = [self.node_colors.get(node, 'lightblue') for node in self.graph.nodes()]
        nx.draw_networkx_nodes(self.graph, self.pos, node_color=node_colors_list,
                               node_size=800, alpha=0.8)

        # Draw edges
        nx.draw_networkx_edges(self.graph, self.pos, edge_color='gray', width=1, alpha=0.5)

        # Highlight specific edges (like MST)
        if highlight_edges:
            nx.draw_networkx_edges(self.graph, self.pos, edgelist=highlight_edges,
                                   edge_color='green', width=3, alpha=0.8)

        # Highlight path
        if highlight_path:
            path_edges = [(highlight_path[i], highlight_path[i + 1]) for i in range(len(highlight_path) - 1)]
            nx.draw_networkx_edges(self.graph, self.pos, edgelist=path_edges,
                                   edge_color='red', width=4, alpha=0.9)

        # Draw labels
        nx.draw_networkx_labels(self.graph, self.pos, font_size=9, font_weight='bold')

        # Draw edge labels (weights)
        edge_labels = {(u, v): d['weight'] for u, v, d in self.graph.edges(data=True)}
        nx.draw_networkx_edge_labels(self.graph, self.pos, edge_labels, font_size=7)

        # Add legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='red', label='Critical Facility (Hospital/Gov)'),
            Patch(facecolor='orange', label='High Population Area'),
            Patch(facecolor='lightblue', label='Normal Area'),
            Patch(facecolor='green', edgecolor='green', label='MST Roads'),
            Patch(facecolor='red', edgecolor='red', label='Selected Path')
        ]
        plt.legend(handles=legend_elements, loc='upper left', fontsize=8)

        plt.title(title, fontsize=16, fontweight='bold')
        plt.axis('off')

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()

    def draw_mst(self, network, mst_edges, save_path=None):
        """Draw the Minimum Spanning Tree"""
        self.build_from_network(network)
        self.draw_network(title="Minimum Spanning Tree - Optimal Road Network",
                          highlight_edges=mst_edges, save_path=save_path)

    def draw_shortest_path(self, network, start, end, path, save_path=None):
        """Draw shortest path between two nodes"""
        self.build_from_network(network)
        self.draw_network(title=f"Shortest Path: {start} → {end}",
                          highlight_path=path, save_path=save_path)

    def draw_comparison(self, network, paths_dict, save_path=None):
        """Draw multiple paths for comparison"""
        plt.figure(figsize=(16, 10))
        self.build_from_network(network)

        # Draw base network
        node_colors_list = [self.node_colors.get(node, 'lightblue') for node in self.graph.nodes()]
        nx.draw_networkx_nodes(self.graph, self.pos, node_color=node_colors_list, node_size=600)
        nx.draw_networkx_edges(self.graph, self.pos, edge_color='lightgray', width=1)

        # Draw each path with different color
        colors = ['red', 'blue', 'green', 'purple', 'orange']
        for i, (name, path) in enumerate(paths_dict.items()):
            if path and len(path) > 1:
                path_edges = [(path[i], path[i + 1]) for i in range(len(path) - 1)]
                nx.draw_networkx_edges(self.graph, self.pos, edgelist=path_edges,
                                       edge_color=colors[i % len(colors)], width=3, alpha=0.7,
                                       label=name)

        nx.draw_networkx_labels(self.graph, self.pos, font_size=8)
        plt.legend(loc='upper left')
        plt.title("Route Comparison", fontsize=14)
        plt.axis('off')

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()