# visualization/charts.py
import matplotlib.pyplot as plt
import numpy as np


class PerformanceCharts:
    """Generate performance charts for algorithm analysis"""

    @staticmethod
    def plot_time_comparison(times_dict, title="Algorithm Performance Comparison"):
        """Plot bar chart comparing algorithm times"""
        algorithms = list(times_dict.keys())
        times = list(times_dict.values())

        plt.figure(figsize=(10, 6))
        colors = plt.cm.viridis(np.linspace(0, 0.8, len(algorithms)))
        bars = plt.bar(algorithms, times, color=colors)

        plt.ylabel('Time (milliseconds)', fontsize=12)
        plt.title(title, fontsize=14, fontweight='bold')
        plt.xticks(rotation=45, ha='right')

        # Add value labels on bars
        for bar, t in zip(bars, times):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                     f'{t:.1f}ms', ha='center', va='bottom', fontsize=9)

        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_traffic_comparison(base_time, traffic_times, title="Traffic Impact Analysis"):
        """Plot comparison of travel times under different traffic conditions"""
        conditions = list(traffic_times.keys())
        times = list(traffic_times.values())

        plt.figure(figsize=(8, 6))
        x = np.arange(len(conditions))
        width = 0.6

        bars = plt.bar(x, times, width, color=['green', 'orange', 'red'])
        plt.axhline(y=base_time, color='blue', linestyle='--',
                    label=f'Base Time: {base_time} min')

        plt.xlabel('Traffic Condition', fontsize=12)
        plt.ylabel('Travel Time (minutes)', fontsize=12)
        plt.title(title, fontsize=14, fontweight='bold')
        plt.xticks(x, conditions)

        for bar, t in zip(bars, times):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                     f'{t:.1f}', ha='center', va='bottom', fontsize=10)

        plt.legend()
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_cost_comparison(costs_dict, title="Transport Mode Cost Comparison"):
        """Plot comparison of costs for different transport modes"""
        modes = list(costs_dict.keys())
        costs = list(costs_dict.values())

        plt.figure(figsize=(10, 6))
        colors = ['gold', 'silver', '#cd7f32', 'green', 'red']
        bars = plt.bar(modes, costs, color=colors[:len(modes)])

        plt.ylabel('Cost (EGP)', fontsize=12)
        plt.title(title, fontsize=14, fontweight='bold')
        plt.xticks(rotation=45, ha='right')

        for bar, c in zip(bars, costs):
            plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                     f'{c:.0f} EGP', ha='center', va='bottom', fontsize=9)

        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_complexity_analysis():
        """Plot Big-O complexity curves"""
        n = np.linspace(1, 100, 100)

        plt.figure(figsize=(12, 7))

        # Different complexity curves
        plt.plot(n, n, label='O(n) - Linear', linewidth=2)
        plt.plot(n, n * np.log2(n), label='O(n log n) - Linearithmic', linewidth=2)
        plt.plot(n, n ** 2, label='O(n²) - Quadratic', linewidth=2)
        plt.plot(n, n ** 3, label='O(n³) - Cubic', linewidth=2)

        plt.xlabel('Input Size (n)', fontsize=12)
        plt.ylabel('Operations', fontsize=12)
        plt.title('Algorithm Complexity Analysis', fontsize=14, fontweight='bold')
        plt.legend()
        plt.grid(True, alpha=0.3)

        # Add annotations
        plt.text(70, 3000, 'Dijkstra: O((V+E) log V)', fontsize=9, style='italic')
        plt.text(70, 5000, 'Kruskal: O(E log E)', fontsize=9, style='italic')
        plt.text(70, 8000, 'DP: O(buses × slots)', fontsize=9, style='italic')

        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_route_summary(path_info, save_path=None):
        """Create a summary dashboard of route information"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # Subplot 1: Time breakdown
        axes[0, 0].bar(path_info.get('time_breakdown', {}).keys(),
                       path_info.get('time_breakdown', {}).values(),
                       color='skyblue')
        axes[0, 0].set_title('Time Breakdown (minutes)')
        axes[0, 0].tick_params(axis='x', rotation=45)

        # Subplot 2: Mode comparison
        modes = list(path_info.get('mode_times', {}).keys())
        times = list(path_info.get('mode_times', {}).values())
        axes[0, 1].bar(modes, times, color='lightcoral')
        axes[0, 1].set_title('Travel Time by Transport Mode')
        axes[0, 1].tick_params(axis='x', rotation=45)

        # Subplot 3: Cost comparison
        costs = list(path_info.get('mode_costs', {}).values())
        axes[1, 0].bar(modes, costs, color='lightgreen')
        axes[1, 0].set_title('Cost by Transport Mode (EGP)')
        axes[1, 0].tick_params(axis='x', rotation=45)

        # Subplot 4: Traffic impact
        traffic = path_info.get('traffic_impact', {})
        axes[1, 1].bar(traffic.keys(), traffic.values(), color=['green', 'orange', 'red'])
        axes[1, 1].set_title('Traffic Impact on Travel Time')
        axes[1, 1].set_ylabel('Minutes')

        plt.suptitle('Route Analysis Dashboard', fontsize=16, fontweight='bold')
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.show()