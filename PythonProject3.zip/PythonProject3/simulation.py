# simulation.py
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from algorithms.core_data import CairoTransportData
from algorithms.dijkstra import DijkstraRouter
from algorithms.astar import AStarRouter
import random


class TrafficSimulation:
    """Simulate traffic incidents and road closures"""

    def __init__(self):
        self.network = CairoTransportData()
        self.network.build_cairo_network()
        self.closed_roads = set()
        self.active_incidents = []

    def simulate_accident(self, road=None):
        """Simulate a road accident"""
        if road is None:
            # Pick a random edge
            all_edges = []
            for u in self.network.graph:
                for v, w in self.network.graph[u]:
                    if u < v:
                        all_edges.append((u, v))
            road = random.choice(all_edges)

        self.closed_roads.add(road)
        self.active_incidents.append({
            'type': 'accident',
            'road': road,
            'time': 'now'
        })

        print(f"\n🚨 ACCIDENT SIMULATED!")
        print(f"   Road closed: {road[0]} ↔ {road[1]}")
        return road

    def get_modified_network(self):
        """Return network with closed roads removed"""

        # Create a temporary network without closed roads
        class ModifiedNetwork:
            def __init__(self, original, closed):
                self.original = original
                self.closed = closed
                self.nodes = original.nodes
                self.critical_facilities = original.critical_facilities
                self.population = original.population

            def get_neighbors(self, node):
                neighbors = []
                for neighbor, weight in self.original.get_neighbors(node):
                    if (node, neighbor) not in self.closed and (neighbor, node) not in self.closed:
                        neighbors.append((neighbor, weight))
                return neighbors

            def get_edge_weight(self, u, v):
                if (u, v) in self.closed or (v, u) in self.closed:
                    return float('inf')
                return self.original.get_edge_weight(u, v)

            def apply_traffic_factor(self, time):
                return self.original.apply_traffic_factor(time)

        return ModifiedNetwork(self.network, self.closed_roads)

    def find_alternative_route(self, start, end):
        """Find alternative route after accident"""
        mod_network = self.get_modified_network()
        path, time, _ = DijkstraRouter.find_shortest_path(mod_network, start, end)

        if path:
            print(f"\n🔄 ALTERNATIVE ROUTE FOUND:")
            print(f"   Path: {' → '.join(path)}")
            print(f"   Time: {time} minutes")
        else:
            print(f"\n❌ No alternative route found!")

        return path, time

    def clear_incident(self):
        """Clear the simulated incident"""
        self.closed_roads.clear()
        self.active_incidents.clear()
        print("\n✅ Incident cleared. Roads恢复正常.")


def run_simulation_demo():
    """Run a complete simulation demo"""
    print("=" * 60)
    print("🚦 TRAFFIC SIMULATION DEMO")
    print("=" * 60)

    sim = TrafficSimulation()

    # Original route
    start, end = "NasrCity", "Giza"
    print(f"\n📍 Route: {start} → {end}")

    path, time, _ = DijkstraRouter.find_shortest_path(sim.network, start, end)
    print(f"\n✅ NORMAL CONDITIONS:")
    print(f"   Path: {' → '.join(path)}")
    print(f"   Time: {time} minutes")

    # Simulate accident
    sim.simulate_accident(("Downtown", "Giza"))

    # Find alternative
    print(f"\n🚨 AFTER ACCIDENT:")
    alt_path, alt_time = sim.find_alternative_route(start, end)

    # Clear and show recovery
    sim.clear_incident()
    path, time, _ = DijkstraRouter.find_shortest_path(sim.network, start, end)
    print(f"\n✅ AFTER INCIDENT CLEARED:")
    print(f"   Path: {' → '.join(path)}")
    print(f"   Time: {time} minutes")


if __name__ == "__main__":
    run_simulation_demo()